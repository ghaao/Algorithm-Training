package myCar;
import org.springframework.context.*;
import org.springframework.context.support.*;

public class carMain {
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");
        
        Car shape1 = (Car)context.getBean("car1");
        shape1.printInfo();
        
        Car shape2 = (Car)context.getBean("car2");
        shape2.printInfo();
       
        Car shape3 = (Car)context.getBean("car3");
        shape3.printInfo();
       
    }
    
}
