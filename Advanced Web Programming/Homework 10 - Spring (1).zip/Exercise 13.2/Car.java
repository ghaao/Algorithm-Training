package myCar;


public abstract class Car {
    public abstract int getYear();
    public abstract String getModel();
    public abstract String getMaker();
    
    public void printInfo(){
        System.out.println("Model : "+getModel() + " / Year : " + getYear() + " / Maker : "+getMaker());
    }
}
