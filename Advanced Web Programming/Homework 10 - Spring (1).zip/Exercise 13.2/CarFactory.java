package myCar;


public class CarFactory {
    public static Car findCar(String model, int year, String maker){
        
        return new RCar(model, year, maker);
    }
    public static Car findCar(String model, int year){
        String maker;
        if(model.equals("sonata")){
            maker = "Hyeondai";
        }else if (model.equals("sportage")){
            maker = "KIA";
        }else{
            maker = "Imported";
        }
        return new RCar(model,year,maker);
    }
}
