package myCar;


public class RCar extends Car{ 
    String model, maker;
    int year;
    
    public RCar(){}
    public RCar(String model, int year, String maker){
        this.model = model;
        this.year = year;
        this.maker = maker;
      }
    public String getModel(){
        return model;
    }
    public String getMaker(){
        return maker;
    }
    public int getYear(){
        return year;
    }
    
    public void setModel(String model){
        this.model = model;
    }
    public void setMaker(String maker){
        this.maker = maker;
    }
    public void setYear(int year){
        this.year = year;
    }
}
