package mySpring;
public class REmployee implements Employee {
    private String name, ID;
    
    public REmployee() {
        name = "";
        ID = "";
    }
    
    public REmployee(String name, String ID) {
        this.name = name;
        this.ID = ID;
    }
    

    public void setName(String name) {
        // TODO Auto-generated method stub
        this.name = name;
    }


    public void setID(String ID) {
        // TODO Auto-generated method stub
        this.ID = ID;
    }

	public void printInfo() {
		// TODO Auto-generated method stub
		System.out.println("Name : " + name + " / ID : "+ID);
	}
}
