package mySpring;
import org.springframework.context.*;
import org.springframework.context.support.*;

public class EmployeeMain {
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");
        
        Employee shape1 = (Employee)context.getBean("person1");
        shape1.printInfo();
        
        Employee shape2 = (Employee)context.getBean("person2");
        shape2.printInfo();
       
        Employee shape3 = (Employee)context.getBean("person3");
        shape3.printInfo();
       
    }
    
}
