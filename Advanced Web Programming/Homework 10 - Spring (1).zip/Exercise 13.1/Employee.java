package mySpring;

public interface Employee {
	public void printInfo();
	
}
