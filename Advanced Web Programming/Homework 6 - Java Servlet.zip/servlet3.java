package com.example.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet3
 */
@WebServlet("/servlet3")
public class servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet3() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    String query = request.getParameter("info");
	    String site = request.getParameter("drop");

	    if(site.equals("Naver"))
            site = "http://search.naver.com/search.naver?query=" + query;
        else if(site.equals("Daum"))
            site = "http://search.daum.net/"+query;
        else if(site.equals("Google"))
            site = "http://www.google.com/search?q="+query;
        else if(site.equals("Yahoo"))
            site = "http://search.yahoo.com/bin/search?p="+query;
        else if(site.equals("Bing"))
            site = "http://www.bing.com/search?q="+query;
      
	    response.sendRedirect(site);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
