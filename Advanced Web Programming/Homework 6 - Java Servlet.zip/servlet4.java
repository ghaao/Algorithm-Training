package com.example.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet4
 */
@WebServlet("/servlet4")
public class servlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    Enumeration<String> paramNames = request.getParameterNames();
        Cookie[] cookies = request.getCookies();
        String naming = (String)paramNames.nextElement();
        String heading ="";
        
        if (cookies == null && !naming.equals("FirstName")) {
            heading = "<form action = 'http://localhost:8080/Registeration/servlet4' method='get'>"
                    + "<label>First Name : </label><input type='text' name ='FirstName' ><br>"
                    + "<label>Last Name : </label><input type='text' name = 'LastName'><br>"
                    + "<label>Email : </label><input type='text' name = 'Email'><br>"
                    + "<label>Phone Number : </label><input type='text' name = 'PhoneNumber'><br>"
                    + "<input type='submit' value = 'submit'></form>";        
        } 
        else if(cookies != null){
             String Fname,Lname,Email,Phone;
            Fname = Lname = Email = Phone = "";
            for(Cookie c : cookies){
                if(c.getName().equals("repeatVisitorFName")) Fname = c.getValue();
                if(c.getName().equals("repeatVisitorLName")) Lname = c.getValue();
                if(c.getName().equals("repeatVisitorEmail")) Email = c.getValue();
                if(c.getName().equals("repeatVisitorPhone")) Phone = c.getValue();                                        
            }
            heading = "<h1>Welcome Back</h1>\n" +
                    "<p>First Name: " +Fname + 
                    "<p>Last Name: "  + Lname +
                    "<p>Email: "  + Email +
                    "<p>Phone Number: "  + Phone;           
        }
        else if(cookies == null && naming.equals("FirstName")){
	            String[] name = new String[4];
	            String[] value = new String[4];
	            String responseText = "<!DOCTYPE html>\n" +
	                        "<html>\n" +
	                        "<head><title>A Simple Servlet</title></head>\n" +
	                        "<body><h1>ReTry</h1>\n";
	            int check = 0, index=0;
	            PrintWriter out2 = response.getWriter();
	            
	            String fValue = request.getParameter(naming);
	            if(fValue == "")
                    responseText = responseText + "First Name" + "<input type='text'><font color='red'> Enter First Name</font><br>";              
                else if(fValue != "")
                    responseText = responseText + "First Name" + "<input type='text' value ='" + fValue +"'> <br>";
	            while(paramNames.hasMoreElements()){
	                name[index] = (String)paramNames.nextElement();
	                String[] values = request.getParameterValues(name[index]);
	                
	                if(values.length == 1 && values[0] == "")
	                    responseText = responseText + name[index] + "<input type='text'><font color='red'> Enter " + name[index]+"</font><br>";	             
	                else if(values.length == 1 && values[0] != ""){
	                    responseText = responseText + name[index] + "<input type='text' value ='" + values[0] +"'> <br>";
	                   
	                    value[index] = values[0];
	                    check++;
	                }
	                index++;
	            }
	            responseText += "</body>";
	            if(check == 3){
	                heading = "<h1>Welcome</h1>\n" +
	                        "<p>First Name: " +value[0] + 
	                        "<p>Last Name: "  + value[1] +
	                        "<p>Email: "  + value[2] +
	                        "<p>Phone Number: "  + value[2];   
	                
	                Cookie returnVisitorCookie = new Cookie("repeatVisitor", "yes");
	                Cookie returnVisitorCookie2 = new Cookie("repeatVisitorFName", fValue);
	                Cookie returnVisitorCookie3 = new Cookie("repeatVisitorLName", value[0]);
	                Cookie returnVisitorCookie4 = new Cookie("repeatVisitorEmail", value[1]);
	                Cookie returnVisitorCookie5 = new Cookie("repeatVisitorPhone", value[2]);
	                returnVisitorCookie.setMaxAge(60);
	                returnVisitorCookie2.setMaxAge(60);
	                returnVisitorCookie3.setMaxAge(60);
	                returnVisitorCookie4.setMaxAge(60);
	                returnVisitorCookie5.setMaxAge(60);
	                
	                response.addCookie(returnVisitorCookie);
                    response.addCookie(returnVisitorCookie2);
                    response.addCookie(returnVisitorCookie3);
                    response.addCookie(returnVisitorCookie4);
                    response.addCookie(returnVisitorCookie5);
	            }
	            else{
	                out2.println(responseText);
	            }
	        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1 style='text-align:center'>" + heading + "</h1>");
	    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
