package com.example.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet1
 */
@WebServlet("/servlet1")
public class servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    String[] name = new String[4];
	    String[] value = new String[4];
	    String responseText = "<!DOCTYPE html>\n" +
                    "<html>\n" +
                    "<head><title>A Simple Servlet</title></head>\n" +
                    "<body><h1>Registeration</h1>\n";
	    int check = 0, index=0;
	    Enumeration<String> paramNames = request.getParameterNames();
	    PrintWriter out = response.getWriter(); 
	    
	    while(paramNames.hasMoreElements()){
	        name[index] = (String)paramNames.nextElement();
	        String[] values = request.getParameterValues(name[index]);
	        
	        if(values.length == 1 && values[0] == ""){
	            responseText = responseText + name[index] + "<input type='text'><font color='red'> Enter " + name[index]+"</font><br>";
	        }
	        else if(values.length == 1 && values[0] != ""){
	            responseText = responseText + name[index] + "<input type='text' value ='" + values[0] +"'> <br>";
	           
	            value[index] = values[0];
	            check++;
	        }
	        index++;
	    }
	    responseText += "</body>";
	    if(check == 4){
	        out.println("<!DOCTYPE html>\n" +
	                "<html>\n" +
	                "<head><title>A Simple Servlet</title></head>\n" +
	                "<body><h1>Read Parameters</h1>\n" +
	                "<p>First Name: " + value[0] + 
	                "<p>Last Name: "  + value[1] +
	                "<p>Email: "  + value[2] +
	                "<p>Phone Number: "  + value[3] +                
	                "</body></html>");

	    }
	    else{
	        out.println(responseText);
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
