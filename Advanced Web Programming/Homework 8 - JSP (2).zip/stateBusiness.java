package com.example.serv;

import java.util.HashMap;
import java.util.Map;

public class stateBusiness {
   private Map<String, statePair> states;
    public stateBusiness(){
    
        states = new HashMap<String, statePair>();
        addState(new statePair("California","CA"));
        addState(new statePair("NewYork","NY"));
        addState(new statePair("Sanfransisco","SF"));
        addState(new statePair("Minesota","MS"));
        addState(new statePair("Chicago","CG"));
        addState(new statePair("Hawaii","HI"));
        addState(new statePair("Kansas","KS"));
        addState(new statePair("Maine","ME"));
        addState(new statePair("Michigan","MI"));
        addState(new statePair("Washington","WA"));
        addState(new statePair("Wisconsin","WI"));
    }
    public statePair findStatePair(String state){
            if(state != null)
                return (states.get(state));
        return null;
    }
    private void addState(statePair statePair) {
        // TODO Auto-generated method stub
        states.put(statePair.getStateName(), statePair);
    }
}