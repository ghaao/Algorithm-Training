package com.example.serv;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet5
 */
@WebServlet("/servlet5")
public class servlet5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet5() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    
	    String stateName = request.getParameter("state");
	    stateBusiness service = new stateBusiness();
	    statePair statePair = service.findStatePair(stateName);
	    
	    request.setAttribute("state", statePair);
	    
	    String address;
	    
	    if (statePair == null) {
	        request.setAttribute("unknownName", stateName);
	        address = "Exercise 10.5_1.jsp";
	     } else {
	        address = "Exercise 10.5_2.jsp";
	        }
	    
	    RequestDispatcher dispatcher =
	     request.getRequestDispatcher(address);
	            dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
