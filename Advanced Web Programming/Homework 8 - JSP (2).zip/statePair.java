package com.example.serv;



public class statePair {
    String stateName, stateAbbreviation;
    
    public statePair(String stateName, String stateAbbreviation){
        this.stateName = stateName;
        this.stateAbbreviation = stateAbbreviation;
    }
    public void setStateName(String state){
        stateName = state;
    }public void setStateAbbreviation(String stateAbb){
        stateAbbreviation = stateAbb;
    }
    public String getStateName(){
        return stateName;
    }public String getStateAbbreviation(){
        return stateAbbreviation;
    }
    
}
