package com.example.bean;


public class headerBean {
    private String host="";
    private String connection="";
    private String cache_control="";
    private String accept="";
    private String user_agent="";
 
    public String getHost(){
        return host;
    }public String getConnection(){
        return connection;
    }public String getCache_control(){
        return cache_control;
    }public String getAccept(){
        return accept;
    }public String getUser_agent(){
        return user_agent;
    }
    
    public void setConnection(String connectionName){
        connection = connectionName;
    }public void setHost(String hostName){
        host = hostName;
    }public void setCache_control(String hostCache_control){
        cache_control = hostCache_control;
    }public void setAccept(String hostAccept){
        accept = hostAccept;
    }public void setUser_agent(String hostUser_agent){
        user_agent = hostUser_agent;
    }    
    
}
