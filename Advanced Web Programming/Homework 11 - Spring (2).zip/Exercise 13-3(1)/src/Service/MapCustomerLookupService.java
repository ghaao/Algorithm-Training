package Service;

import java.util.Map;

import Model.Customer;

public class MapCustomerLookupService implements CustomerLookupService {
	private Map<String, Customer> cusDatabase;
	
	@Override
	public Customer getCustomer(String id) {
		if(id == null) id="unknown";
		
		return cusDatabase.get(id.toLowerCase());
	}
	
	@Override
	public Customer getRichestCustomer() {
		Customer richestCustomer = null;
		double maxBalance = 0;
		
		for(Customer c : cusDatabase.values()){
			if(c.getBalance() > maxBalance){
				richestCustomer = c;
				maxBalance = c.getBalance();
			}
		}
		
		return richestCustomer;
	}
	
	@Override
	public boolean isEmpty(String id){
		
		for(String key : cusDatabase.keySet()){
			if(key.equals(id))
				return true;
		}
		return false;
	}

	public Map<String, Customer> getCusDatabase() {
		return cusDatabase;
	}

	public void setCusDatabase(Map<String, Customer> cusDatabase) {
		this.cusDatabase = cusDatabase;
	}

	@Override
	public String toString() {
		return "MapCustomerLookupService [cusDatabase=" + cusDatabase + "]";
	}
	
	

}
