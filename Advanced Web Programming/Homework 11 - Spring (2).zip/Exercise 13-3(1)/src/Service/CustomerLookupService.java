package Service;

import Model.Customer;

public interface CustomerLookupService {
	public Customer getCustomer(String id);
	public Customer getRichestCustomer();
	public boolean isEmpty(String id);
}
