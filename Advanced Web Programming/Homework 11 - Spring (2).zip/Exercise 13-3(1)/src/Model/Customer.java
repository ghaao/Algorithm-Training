package Model;

public class Customer {
	
	private String customerID, name;
	private double balance;
	
	public String getFormattedBanalce(){
		return (String.format("$%,.2f", getBalance()));
		
	}
	
	public Customer() {
		super();
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public static boolean isEmpty(String param) {
        return((param == null) || (param.trim().equals("")));
    }
}
