package myPackage;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context =
	            new ClassPathXmlApplicationContext("/applicationContext.xml");
            Employee person1 = (Employee)context.getBean("person1");
            Employee person2 = (Employee)context.getBean("person2");
            
            person1.printInfo();
            person2.printInfo();
	}

}
