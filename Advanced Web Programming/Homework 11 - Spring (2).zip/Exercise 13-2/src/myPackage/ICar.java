package myPackage;

public interface ICar {
	public abstract void printInfo();

}
