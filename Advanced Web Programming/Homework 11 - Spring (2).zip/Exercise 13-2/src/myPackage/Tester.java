package myPackage;

import java.util.List;

public class Tester implements Employee{
	
	private int id;
	private String name;
	private List<Car> cars;
	
	public Tester() {
		// TODO Auto-generated constructor stub
	}
	

	public Tester(int id, String name, List<Car> cars) {
		super();
		this.id = id;
		this.name = name;
		this.cars = cars;
	}

	public List<Car> getCars() {
		return cars;
	}


	public void setCars(List<Car> cars) {
		this.cars = cars;
	}


	public Tester(int id, String name) {

		this.id = id;
		this.name = name;
		// TODO Auto-generated constructor stub
	}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public void printInfo() {
		System.out.println(id + " " + name + " ");
		for(Car myCars : cars){
			System.out.println(myCars);
		}
		
	}

}
