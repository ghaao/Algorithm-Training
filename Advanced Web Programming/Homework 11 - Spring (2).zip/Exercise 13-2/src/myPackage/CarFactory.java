package myPackage;

public class CarFactory {
	
	public static Car makeCar(String model, int year){
	
		return makeCar(model, year, findMaker(model));
	}
	
	private static String findMaker(String model){
		
		switch(model){
		
			case "SONATA":
				return "HYUNDAI";
			case "SPARK":
				return "chevrolet";
			default :
				return "KIA";
		}
	}
	
	public static Car makeCar(String model, int year, String maker){
		
		return new Car(model, year, maker);
	}
}
