package myPackage;

public interface Employee {
	
	public abstract void printInfo();

}
