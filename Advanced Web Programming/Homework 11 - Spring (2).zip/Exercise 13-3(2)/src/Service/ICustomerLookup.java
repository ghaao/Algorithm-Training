package Service;

import Model.Customer;

public interface ICustomerLookup {
	public Customer findCustomer(String id);
	public void addCustomer(Customer customer);
}
