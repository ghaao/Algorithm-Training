package Service;

import java.util.Map;

import Model.Customer;

public class CustomerLookup implements ICustomerLookup{
	private Map<String,Customer> customers;
	
    public Customer findCustomer(String id){

		if (id != null)
			  return(customers.get(id.toLowerCase()));
   
        return null;
    }
    public void addCustomer(Customer customer) {
    	customers.put(customer.getId(), customer);
    }
	public Map<String, Customer> getCustomers() {
		return customers;
	}
	
	public void setCustomers(Map<String, Customer> customers) {
		this.customers = customers;
	}
}
