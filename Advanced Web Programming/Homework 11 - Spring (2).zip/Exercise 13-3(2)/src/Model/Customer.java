package Model;

public class Customer {
    private String id, firstName, lastName;
    private double balance, balanceNoSign;
    
    
 
	public Customer() {
		super();
	}
	
	public Customer(String id, String firstName, String lastName, double balance, double balanceNoSign) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
		this.balanceNoSign = balanceNoSign;
	}


	
	

	public void setId(String id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setBalanceNoSign(double balanceNoSign) {
		this.balanceNoSign = balanceNoSign;
	}

	public String getId() {
		return id;
	}



	public String getFirstName() {
		return firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public double getBalance() {
		return balance;
	}



	public double getBalanceNoSign() {
		return balanceNoSign;
	}




}
