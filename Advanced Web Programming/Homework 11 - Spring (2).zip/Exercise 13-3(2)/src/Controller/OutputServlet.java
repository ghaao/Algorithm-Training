package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import Model.Customer;
import Service.CustomerLookup;
import Service.ICustomerLookup;

/**
 * Servlet implementation class OutputServlet
 */
@WebServlet("/output-form")
public class OutputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ICustomerLookup lookupService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OutputServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	super.init();
    	
        ApplicationContext context =
	            WebApplicationContextUtils.
	                getRequiredWebApplicationContext(getServletContext());
        lookupService = (CustomerLookup)context.getBean("customerLookupService");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String customerId = request.getParameter("customerId");
		Customer customer = lookupService.findCustomer(customerId);  
		request.setAttribute("customer", customer);
		
		String address;
		if (customer == null) {
		    request.setAttribute("unknownId", customerId);
		    address = "unknown.jsp";
		} else if (customer.getBalance() < 0) {
		    address = "negative.jsp";
		} else if (customer.getBalance() < 10000) {
		    address = "normal.jsp";
		} else {
		    address = "vip.jsp";
		}
		
		RequestDispatcher dispatcher =
		    request.getRequestDispatcher(address);
		dispatcher.forward(request, response);
	}



}
