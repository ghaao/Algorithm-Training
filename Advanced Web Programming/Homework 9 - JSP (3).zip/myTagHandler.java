package tagHandler;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;


public class myTagHandler extends TagSupport {
    private static final long serialVersionUID = 1L;
 
    @Override
    public int doStartTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            double rnd = Math.random();
            out.print("커스텀 태그 출력 메시지 : " + rnd);
        } catch (IOException e) {
            e.printStackTrace();
        }
         
        return SKIP_BODY;
    }
}