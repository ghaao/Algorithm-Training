package com.example.term;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;


public class DBmanager {


	String result = "";
	ArrayList<NameValuePair> nameValuePairs;

	public DBmanager(){

		nameValuePairs = new ArrayList<NameValuePair>();
	}

	public JSONArray requestQuery(String sql){

		InputStream is = null;
		nameValuePairs.add(new BasicNameValuePair("sql",sql));

		Log.e("error", "nameValuePairs: " + nameValuePairs.get(0).toString());

		try{	

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://172.16.23.205:8080/getter_mp.php");

			Log.e("error","5");

			UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs,"utf-8"); 
			httppost.setEntity(entityRequest);

			Log.e("error", "encodeEntity: "+ entityRequest);

			Log.e("error","6");

			HttpResponse response = httpclient.execute(httppost);

			Log.e("error","7");

			HttpEntity entity = response.getEntity();	

			is = entity.getContent();

			Log.e("error","8");

		}catch(Exception e){

			Log.e("error", "Error in http connection "+e.toString());

		}

		Log.e("log_tag", "result: "+result);

		//convert response to string

		try{

			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"),8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			Log.e("error","9");
			while ((line = reader.readLine()) != null) {

				Log.e("error", "line: "+line);

				sb.append(line + "\n");

			}

			is.close();

			result=sb.toString();

			Log.e("error", "result: "+result);

			Log.e("error","11");

		}catch(Exception e){

			Log.e("log_tag", "Error converting result "+e.toString());

		}



		//parse json data

		try{

			Log.e("error","12");
			if(result.equals("1\n")) Log.e("DBERROR", "connection error");
			if(result.equals("2\n")) Log.e("DBERROR", "db selection error");
			if(result.equals("3\n")) Log.e("DBERROR", "request error");
			if(result.equals("4\n")) Log.e("DBERROR", "sql query error");

			else {

				Log.e("error","13");
				JSONArray jArray = new JSONArray(result);

				/*				
				for(int i=0;i<jArray.length();i++){

					JSONObject json_data = jArray.getJSONObject(i);

					Log.e("error","ID : " + json_data.getString("ID"));
					Log.e("error","pass : " + json_data.getString("pass"));
					Log.e("error","name : " + json_data.getString("name"));
					Log.e("error","code : " + json_data.getInt("code"));
				}

				 */
				Log.e("error","aaaa" + jArray.length());
				return jArray;



			}

		}catch(JSONException e){

			Log.e("log_tag", "Error parsing data "+e.toString());

		}

		return null;

	}



	public boolean sendQuery(String sql){

		InputStream is = null;
		nameValuePairs.add(new BasicNameValuePair("sql",sql));

		//http post

		try{	

			HttpClient httpclient = new DefaultHttpClient();
			Log.e(null,"10");

			HttpPost httppost = new HttpPost("http://172.16.23.205:8080/setter_mp.php");
			Log.e(null,"11");

			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs,"utf-8"));
			Log.e(null,"12");

			HttpResponse response = httpclient.execute(httppost);
			Log.e(null,"13");

			HttpEntity entity = response.getEntity();

			is = entity.getContent();

		}catch(Exception e){
			Log.e(null, "Error in http connection "+e.toString());
		}

		//convert response to string

		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"),8);
			StringBuilder sb = new StringBuilder();
			String line = null;

			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}

			is.close();
			result=sb.toString();

		}catch(Exception e){

			Log.e(null, "Error converting result "+e.toString());

		}

		if(result.equals("1\n")) 
			Log.e(null, "connection error");
		if(result.equals("2\n")) 
			Log.e(null, "db selection error");
		if(result.equals("3\n")) 
			Log.e(null, "request error");
		if(result.equals("4\n")) 
			Log.e(null, "sql query error");
		if(result.equals("5\n"))
		{
			Log.i("DB", "query success");
			Log.e(null,"query success");

			return false;
		}
		return true;
	}
}
