package com.example.term;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MySchedule extends Activity implements OnClickListener {

	private static final int DIALOG_DATE = 0;
	private DBmanager db;

	private Button dateSelectBtn;
	private Button finishbtn;
	private TextView titleTextView;
	private ListView lv1;

	private ArrayList<String> list ;
	private ArrayAdapter<String> adapter;

	private String startYear, startMonth, startDays;
	private String endYear, endMonth, endDays;
	private String pickDate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_myschedule);
		getActionBar().hide();
		db = new DBmanager();

		dateSelectBtn = (Button)findViewById(R.id.datePick);
		titleTextView = (TextView)findViewById(R.id.dateText);
		finishbtn = (Button)findViewById(R.id.rotation_okBtn);

		lv1 = (ListView)findViewById(R.id.workList1);

		list = new ArrayList<String>();

		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);

		lv1.setAdapter(adapter);

		dateSelectBtn.setOnClickListener(this);
		finishbtn.setOnClickListener(this);
		new getDateTask().execute(menuActivity.locationCode);
	}


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == dateSelectBtn.getId()){
			showDialog(DIALOG_DATE);
		}
		if(v.getId() == finishbtn.getId())
			finish();
	}

	protected Dialog onCreateDialog(int id) {
		DatePickerDialog _date = null;

		switch (id) {
		case DIALOG_DATE:
			_date =  new DatePickerDialog(this,  dateListener,
					Integer.parseInt(startYear), Integer.parseInt(startMonth)-1, Integer.parseInt(startDays)){
				@Override
				public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth){   

					if (year > Integer.parseInt(endYear))
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));

					if (monthOfYear > Integer.parseInt(endMonth) - 1 && year == Integer.parseInt(endYear))
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));

					if (dayOfMonth > Integer.parseInt(endDays) && year == Integer.parseInt(endYear) && monthOfYear == Integer.parseInt(endMonth) - 1)
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));


					//these below lines of code used for setting the maximum as well as minimum dates on Date Picker Dialog..
					if (year < Integer.parseInt(startYear))
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));

					if (monthOfYear < Integer.parseInt(startMonth) - 1 && year == Integer.parseInt(startYear) )
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));



					if (dayOfMonth < Integer.parseInt(startDays) && year == Integer.parseInt(startYear) && monthOfYear == Integer.parseInt(startMonth) - 1)
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));

				}
			};      
		}
		return _date;
	}

	private DatePickerDialog.OnDateSetListener dateListener = new DatePickerDialog.OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			pickDate = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;
			dateSelectBtn.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
			new getTask().execute(menuActivity.locationCode);
		}
	};


	private class getTask extends AsyncTask<String, JSONArray, Void>{
		private final ProgressDialog dialog = new ProgressDialog(MySchedule.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(String... params) {

			Log.e("error","+11");
			String query = "select * from fixed_info where locationCode = '" + params[0] + 
					"' and workDate = '" + pickDate +"' and name = '" + menuActivity.name + "';";
			Log.e("mySchedule","+22");
			JSONArray workInfo = db.requestQuery(query);

			Log.e("mySchedule","+33");
			try {
				list.clear();
				for(int i = 0; i < workInfo.length(); i++){

					JSONObject workOBJ = workInfo.getJSONObject(i);
					String caseOfWork = workOBJ.getString("fixedTime");

					Log.e("error","+++++++++++++++++++++++++++" + caseOfWork);


					if(caseOfWork.equals("1")){
						list.add("Open : " + workOBJ.getString("name"));
					}if(caseOfWork.equals("12")){
						list.add("Open : " +workOBJ.getString("name"));
						list.add("Middle : " +workOBJ.getString("name"));
					}if(caseOfWork.equals("13")){
						list.add("Open : " +workOBJ.getString("name"));
						list.add("Close : " +workOBJ.getString("name"));
					}if(caseOfWork.equals("123")){
						Log.e("mySchedule","+99");
						list.add("Open : " +workOBJ.getString("name"));
						list.add("Middle : " +workOBJ.getString("name"));
						list.add("Close : " +workOBJ.getString("name"));
						Log.e("mySchedule","+1010");
					}if(caseOfWork.equals("2")){
						list.add("Middle : " +workOBJ.getString("name"));
					}if(caseOfWork.equals("23")){
						list.add("Middle : " +workOBJ.getString("name"));
						list.add("Close : " +workOBJ.getString("name"));
					}if(caseOfWork.equals("3")){
						list.add("Close : " +workOBJ.getString("name"));
					}
				}

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   

			Log.e("error","+44");
			publishProgress();

			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {
			super.onProgressUpdate(values);

			adapter.notifyDataSetChanged();
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			super.onPostExecute(result);
		}
	}




	private class getDateTask extends AsyncTask<String, JSONArray, Void>{
		private final ProgressDialog dialog = new ProgressDialog(MySchedule.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(String... params) {

			String query = "select * from location_info where locationCode = '" + params[0] + "';";

			JSONArray dateInfo = db.requestQuery(query);

			publishProgress(dateInfo);

			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {
			super.onProgressUpdate(values);

			try
			{
				JSONObject json_data = values[0].getJSONObject(0);

				String startDate = json_data.getString("startDate");
				String endDate= json_data.getString("endDate");

				String temp[] = startDate.split("-");
				String temp2[] = endDate.split("-");

				startYear = temp[0];
				startMonth = temp[1];
				startDays = temp[2];

				endYear = temp2[0];
				endMonth = temp2[1];
				endDays = temp2[2];

			}catch(Exception e){
				Log.e("error",e.getMessage());
			}
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			super.onPostExecute(result);
		}
	}
}