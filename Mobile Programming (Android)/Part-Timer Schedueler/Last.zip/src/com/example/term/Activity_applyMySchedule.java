package com.example.term;



import org.json.JSONArray;
import org.json.JSONObject;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_applyMySchedule extends Activity implements OnClickListener {

	private static final int DIALOG_DATE = 0;
	private DBmanager db;

	private TextView durationText;
	private Button dateSelectBtn;
	private CheckBox openCheckBox;
	private CheckBox middleCheckBox;
	private CheckBox closeCheckBox;
	private Button saveBtn;
	// private TextView titleTextView;

	private String startYear, startMonth, startDays;
	private String endYear, endMonth, endDays;

	private String openNum, middleNum, closeNum;

	private String isCheckOpen, isCheckMiddle, isCheckClose; 

	private String name, ID, locationCode, workDate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_applymyschedule);
		db = new DBmanager();
		getActionBar().hide();


		durationText = (TextView)findViewById(R.id.applyduration);
		dateSelectBtn = (Button)findViewById(R.id.selectDataBtn);
		// titleTextView = (TextView)findViewById(R.id.applyScheduleTitle);
		openCheckBox = (CheckBox)findViewById(R.id.openCheckBox);
		middleCheckBox = (CheckBox)findViewById(R.id.middleCheckBox);
		closeCheckBox = (CheckBox)findViewById(R.id.closeCheckBox);
		saveBtn = (Button)findViewById(R.id.saveBtn);


		dateSelectBtn.setOnClickListener(this);
		saveBtn.setOnClickListener(this);

		ID = menuActivity.ID;
		locationCode = menuActivity.locationCode;
		name = menuActivity.name;
		

		new getDateTask().execute(menuActivity.locationCode);
		Log.e("씨발18","씨발");
	}


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == dateSelectBtn.getId())
			showDialog(DIALOG_DATE);
		else if(v.getId() == saveBtn.getId())
		{
			isCheckOpen = Boolean.toString(openCheckBox.isChecked());
			isCheckMiddle = Boolean.toString(middleCheckBox.isChecked());
			isCheckClose = Boolean.toString(closeCheckBox.isChecked());


			new saveWorkInfoTask().execute(locationCode,ID,name,workDate,isCheckOpen,isCheckMiddle,isCheckClose);

		}
	}

	public void onCheckBoxClicked(View v)
	{

		if(v.getId() == openCheckBox.getId())
		{
			Log.e("error","1");
			Log.e("error","openNum : " + openNum);
			if(openNum.equalsIgnoreCase("0"))
			{

				openCheckBox.setChecked(false);

				Toast.makeText(this, "지원 인원이 초과 하였습니다", Toast.LENGTH_SHORT).show();
			}   
		}
		if(v.getId() == middleCheckBox.getId())   
		{
			Log.e("error","openNum : " + middleNum);
			if(middleNum.equalsIgnoreCase("0"))
			{

				middleCheckBox.setChecked(false);
				Toast.makeText(this, "지원 인원이 초과 하였습니다", Toast.LENGTH_SHORT).show();
			}      
		}
		if(v.getId() == middleCheckBox.getId())
		{
			Log.e("error","openNum : " + closeNum);
			if(closeNum.equalsIgnoreCase("0"))
			{
				closeCheckBox.setChecked(false);
				Toast.makeText(this, "지원 인원이 초과 하였습니다", Toast.LENGTH_SHORT).show();
			}      
		}
	}

	protected Dialog onCreateDialog(int id) {
		DatePickerDialog _date = null;

		switch (id) {
		case DIALOG_DATE:
			_date =  new DatePickerDialog(this,  dateListener,
					Integer.parseInt(startYear), Integer.parseInt(startMonth)-1, Integer.parseInt(startDays)){
				@Override
				public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth)
				{   


					if (year > Integer.parseInt(endYear))
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));

					if (monthOfYear > Integer.parseInt(endMonth) - 1 && year == Integer.parseInt(endYear))
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));

					if (dayOfMonth > Integer.parseInt(endDays) && year == Integer.parseInt(endYear) && monthOfYear == Integer.parseInt(endMonth) - 1)
						view.updateDate(Integer.parseInt(endYear), Integer.parseInt(endMonth) - 1, Integer.parseInt(endDays));


					//these below lines of code used for setting the maximum as well as minimum dates on Date Picker Dialog..
					if (year < Integer.parseInt(startYear))
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));

					if (monthOfYear < Integer.parseInt(startMonth) - 1 && year == Integer.parseInt(startYear) )
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));



					if (dayOfMonth < Integer.parseInt(startDays) && year == Integer.parseInt(startYear) && monthOfYear == Integer.parseInt(startMonth) - 1)
						view.updateDate(Integer.parseInt(startYear), Integer.parseInt(startMonth) - 1, Integer.parseInt(startDays));

				}
			};      
		}
		return _date;
	}



	private DatePickerDialog.OnDateSetListener dateListener = new DatePickerDialog.OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			//possibleDate = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;
		
	
			dateSelectBtn.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
			openCheckBox.setChecked(false);
			middleCheckBox.setChecked(false);
			closeCheckBox.setChecked(false);
			workDate = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;

			new getMySaveDataTask().execute(year+"-"+(monthOfYear+1)+ "-"+ dayOfMonth);
		}
	};

	private class getMySaveDataTask extends AsyncTask<String, JSONArray, Void>
	{
		private final ProgressDialog dialog = new ProgressDialog(Activity_applyMySchedule.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog.setMessage("저장 정보를 불러오는 중입니다.");
			dialog.show();
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(String... params) {

			String query = "select applyTime from applytask_info where ID = '" + ID + "' and workDate = '" + params[0] + "';";
			
			
			Log.e("error",query + " ==========");
			JSONArray one = db.requestQuery(query);
			publishProgress(one);
			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {
			super.onProgressUpdate(values);


			if(values[0].length() != 0){
				try
				{
					JSONObject json_data = values[0].getJSONObject(0);

					String applyTime = json_data.getString("applyTime");
					
					Log.e("error" , applyTime + " +++++++++++++++");

					if(applyTime.equals("123"))
					{
						openCheckBox.setChecked(true);
						middleCheckBox.setChecked(true);
						closeCheckBox.setChecked(true);
					}
					else if(applyTime.equals("12"))
					{
						openCheckBox.setChecked(true);
						middleCheckBox.setChecked(false);
						closeCheckBox.setChecked(true);
					}
					else if(applyTime.equals("23"))
					{
						openCheckBox.setChecked(false);
						middleCheckBox.setChecked(true);
						closeCheckBox.setChecked(true);
					}
					else if(applyTime.equals("13"))
					{
						openCheckBox.setChecked(true);
						middleCheckBox.setChecked(false);
						closeCheckBox.setChecked(true);
					}
					else if(applyTime.equals("1"))
					{
						openCheckBox.setChecked(true);
						middleCheckBox.setChecked(false);
						closeCheckBox.setChecked(false);
					}
					else if(applyTime.equals("2"))
					{
						openCheckBox.setChecked(false);
						middleCheckBox.setChecked(true);
						closeCheckBox.setChecked(false);
					}
					else if(applyTime.equals("3"))
					{
						openCheckBox.setChecked(false);
						middleCheckBox.setChecked(false);
						closeCheckBox.setChecked(true);
					}

				}catch(Exception e)
				{
					Log.e("error",e.getMessage());
				}
			}

		}


		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			super.onPostExecute(result);
		}
	}





	private class saveWorkInfoTask extends AsyncTask<String, Void, Void>
	{

		private final ProgressDialog dialog = new ProgressDialog(Activity_applyMySchedule.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(String... params) {

			JSONArray one = db.requestQuery("select * from applytask_info where ID = '" + params[1] + "' and workDate = '" + params[3] + "';");
			String query = null;

			if(one.length() == 0)
			{
				if(params[4].equals("true") && params[5].equals("true") && params[6].equals("true"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','123'" + ")";
				else if(params[4].equals("true") && params[5].equals("true") && params[6].equals("false"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','12'" + ")";
				else if(params[4].equals("true") && params[5].equals("false") && params[6].equals("true"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','13'" + ")";
				else if(params[4].equals("false") && params[5].equals("true") && params[6].equals("true"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','23'" + ")";
				else if(params[4].equals("fasle") && params[5].equals("false") && params[6].equals("true"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','3'" + ")";
				else if(params[4].equals("false") && params[5].equals("true") && params[6].equals("false"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','2'" + ")";
				else if(params[4].equals("true") && params[5].equals("false") && params[6].equals("false"))
					query = "insert into applytask_info values('" + params[0] +"','" + params[1] + "','" + params[2] +"','" + params[3] + "','1'" + ")";
			}
			else
			{
				if(params[4].equals("true") && params[5].equals("true") && params[6].equals("true"))
					query = "update location_info set applyTime = '123';";
				else if(params[4].equals("true") && params[5].equals("true") && params[6].equals("false"))
					query = "update location_info set applyTime = '12';";
				else if(params[4].equals("true") && params[5].equals("false") && params[6].equals("true"))
					query = "update location_info set applyTime = '13';";
				else if(params[4].equals("false") && params[5].equals("true") && params[6].equals("true"))
					query = "update location_info set applyTime = '23';";
				else if(params[4].equals("fasle") && params[5].equals("false") && params[6].equals("true"))
					query = "update location_info set applyTime = '3';";
				else if(params[4].equals("false") && params[5].equals("true") && params[6].equals("false"))
					query = "update location_info set applyTime = '2';";
				else if(params[4].equals("true") && params[5].equals("false") && params[6].equals("false"))
					query = "update location_info set applyTime = '1';";
			}

			db.sendQuery(query);

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			Toast.makeText(getApplicationContext(), "신청이 완료 되었습니다."   , Toast.LENGTH_SHORT).show();

			super.onPostExecute(result);
		}
	}


	private class getDateTask extends AsyncTask<String, JSONArray, Void>
	{
		private final ProgressDialog dialog = new ProgressDialog(Activity_applyMySchedule.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			Log.e("씨발17","씨발");
			dialog.setMessage("잠시만 기다려 주세요.");
			Log.e("씨발16","씨발");
			dialog.show();
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(String... params) {

			Log.e("error","+1");
			String query = "select startDate, endDate, openNum, middleNum, closeNum from location_info where locationCode = '" + params[0] + "';";
			Log.e("error","+2");
			JSONArray dateInfo = db.requestQuery(query);
			Log.e("error","+3");
			publishProgress(dateInfo);

			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {
			super.onProgressUpdate(values);
			Log.e("error","+4");
			try
			{
				JSONObject json_data = values[0].getJSONObject(0);

				String startDate = json_data.getString("startDate");
				String endDate= json_data.getString("endDate");
				openNum = json_data.getString("openNum");
				middleNum = json_data.getString("middleNum");
				closeNum = json_data.getString("closeNum");

				Log.e("error", "s : " + startDate);
				Log.e("error", "e : " + endDate);

				String temp[] = startDate.split("-");
				String temp2[] = endDate.split("-");

				startYear = temp[0];
				startMonth = temp[1];
				startDays = temp[2];

				endYear = temp2[0];
				endMonth = temp2[1];
				endDays = temp2[2];

				Log.e("error","+5");
				durationText.setText("available apply duration : " + startDate + " ~ " + endDate);
			}catch(Exception e)
			{
				Log.e("error",e.getMessage());
			}
			Log.e("error","+6");

		}


		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			super.onPostExecute(result);
		}
	}

}