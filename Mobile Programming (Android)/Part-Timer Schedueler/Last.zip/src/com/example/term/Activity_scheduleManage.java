
package com.example.term;


import org.json.JSONArray;
import org.json.JSONObject;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_scheduleManage extends Activity implements OnClickListener{

	private static final int DIALOG_DATE = 0;
	private static final int DIALOG_DATE2 = 2;
	private DBmanager db;
	private TextView openText, middleText, closeText;
	private Button commitButton;
	Button datePickButton,dateWorkButton ;
	private String possibleDate = "", workDate = "";
	private String openN, middleN, closeN;
	private String[] ch1 = {"1","2","3","4","5","6","7" };
	private String[] ch2 = {"1","2","3","4","5","6","7","8","9"};
	private String[] ch3 = {"1","2","3","4","5","6","7","8"};
	private Spinner open, middle, close;
	


	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		Log.e("error","-09-09-1");
		setContentView(R.layout.activity_schedulemanage);
		 getActionBar().hide();
		datePickButton = (Button)findViewById(R.id.datePickButton);
		dateWorkButton = (Button)findViewById(R.id.datePickButton2);
		Log.e("error","2");
		open = (Spinner)findViewById(R.id.openNumber);
		middle = (Spinner)findViewById(R.id.middleNumber);
		close = (Spinner)findViewById(R.id.closeNumber);
		open.setPrompt("Open ");
		middle.setPrompt("Middle ");
		close.setPrompt("Close ");
		Log.e("error","3");
		ArrayAdapter<String> list1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,ch1 );
		open.setAdapter(list1);

		ArrayAdapter<String> list2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,ch2 );
		middle.setAdapter(list2);

		ArrayAdapter<String> list3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,ch3 );
		close.setAdapter(list3);
		Log.e("error","4");
		datePickButton.setOnClickListener(this);
		dateWorkButton.setOnClickListener(this);
		Log.e("error","5");

		//get Number of people each time
		open.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				//selMenu = (String) menuSpinner.getSelectedItem();
				openN  = (String)open.getSelectedItem();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub      
			}   
		});
		middle.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				middleN = (String)middle.getSelectedItem();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub      
			}   
		});
		close.setOnItemSelectedListener(new OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				closeN = (String)close.getSelectedItem();
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub      
			}   
		});
		commitButton = (Button)findViewById(R.id.schduleManage_commit);
		commitButton.setOnClickListener(this);

		Log.e("error","6");

	}

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.datePickButton:
			showDialog(DIALOG_DATE);
			break;
		case R.id.datePickButton2:
			showDialog(DIALOG_DATE2);
			break;
		case R.id.schduleManage_commit:
			db = new DBmanager();
			AlertDialog dialBox = createDialogBox();
			dialBox.show();
			String loc = menuActivity.locationCode;
			//update location table

			//Toast.makeText(this, "Open : " + openN + "/ Middle : "+middleN +"/ Close : "+closeN, Toast.LENGTH_SHORT).show();
			break;

		}
	}

	private AlertDialog createDialogBox(){
		AlertDialog myQuittingDialogBox =new AlertDialog.Builder(this)
		//set message, title, and icon
		.setTitle("Question")
		.setMessage("기존의 등록이 사라질 수 있습니다. 계속 진행하시겠습니까?")
		.setIcon(R.drawable.ic_launcher)
		//set three option buttons
		.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				//whatever should be done when answering "YES" goes here
				new openPartTimeTask().execute();
			}
		})//setPositiveButton
		.setNegativeButton("NO", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				//whatever should be done when answering "NO" goes here
			}
		})//setNegativeButton
		.create();
		return myQuittingDialogBox;
	}// createDialogBox
	// clas
	@Override
	protected Dialog onCreateDialog(int id){
		if(id == DIALOG_DATE)
			return new DatePickerDialog(this, dateListener, 2015, 5, 1);

		if(id == DIALOG_DATE2)
			return new DatePickerDialog(this, dateListener2, 2015, 5, 1);

		return null;
	}

	private DatePickerDialog.OnDateSetListener dateListener = 
			new DatePickerDialog.OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			possibleDate = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;
			datePickButton.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
		}
	};

	private DatePickerDialog.OnDateSetListener dateListener2 = 
			new DatePickerDialog.OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			workDate = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;
			dateWorkButton.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
		}
	};


	private class openPartTimeTask extends AsyncTask<String, JSONArray, Void>{

		private final ProgressDialog dialog = new ProgressDialog(Activity_scheduleManage.this);
		boolean check = false;
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요");
			dialog.show();

			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {


			String query = "update location_info set state = '1',  startDate = '" + possibleDate + "', endDate = '" + workDate + "', openNum = '" + openN + "', middleNum = '" + middleN + "', closeNum = '" + closeN + "'  where locationCode = '" + menuActivity.locationCode + "';";

			Log.d("aa",query);
			check = db.sendQuery(query);
			Log.d("a",""+check);
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {

			if(check){

				if(dialog.isShowing())
					dialog.dismiss();

				Toast.makeText(getApplicationContext(), "Complete.", Toast.LENGTH_SHORT).show();
				finish();
			}else{

				if(dialog.isShowing())
					dialog.dismiss();

				Toast.makeText(getApplicationContext(), "Fail.", Toast.LENGTH_SHORT).show();
			}


			super.onPostExecute(result);
		}
	}

}