package com.example.term;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class menuActivity extends Activity implements OnClickListener{

	private Person myInfo;
	private Button mySchedule, applyScedule, bulletineBoard, enrollmentScedule, fixSchedule;
	private Button peopleManageBtn;
	private Button backBtn;
	private Intent myIntent;

	private DBmanager db;
	public static String openCode;
	public static String locationCode;
	public static String positionCode;
	public static String name;
	public static String ID;
	public static String state;

	private boolean bExit = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);

		ActionBar a = getActionBar();
		a.hide();

		db = new DBmanager();
		//get Person information
		myIntent = getIntent();
		Bundle myBundle = myIntent.getExtras();
		myInfo = (Person)myBundle.getSerializable("myInfo");

		openCode = myInfo.getOpenCode();
		locationCode = myInfo.getLocationCode();
		positionCode = myInfo.getCode();
		name = myInfo.getName();
		ID = myInfo.getId();

		new getStateTask().execute();

		applyScedule = (Button)findViewById(R.id.buttonApplyScedule);
		mySchedule = (Button)findViewById(R.id.buttonMySchedule);
		bulletineBoard = (Button)findViewById(R.id.buttonBulletinboard);
		enrollmentScedule = (Button)findViewById(R.id.buttonEnrollmentSchedule);
		peopleManageBtn = (Button)findViewById(R.id.buttonPeopleManage);
		fixSchedule = (Button)findViewById(R.id.menu_fixSchedule);
		backBtn =  (Button)findViewById(R.id.menu_backBtn);

		mySchedule.setOnClickListener(this);
		applyScedule.setOnClickListener(this);
		bulletineBoard.setOnClickListener(this);
		enrollmentScedule.setOnClickListener(this);
		peopleManageBtn.setOnClickListener(this);
		fixSchedule.setOnClickListener(this);
		backBtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		if(v.getId() == mySchedule.getId()){
			if(openCode.equals("1"))
				startActivity(new Intent(this, MySchedule.class));
			else
				Toast.makeText(this, "권한이 없습니다 매니저에게 문의하세요.", Toast.LENGTH_SHORT).show();
		}

		if(v.getId() == applyScedule.getId()){

			if(positionCode.equals("1"))
				startActivity(new Intent(this, Activity_applyMySchedule.class));
			else if(positionCode.equals("0") && openCode.equals("0"))
				Toast.makeText(this, "권한이 없습니다 매니저에게 문의하세요.", Toast.LENGTH_SHORT).show();
			else if(openCode.equals("1")&& state.equals("0") && positionCode.equals("0") )
				Toast.makeText(this, "신청 기간이 아닙니다.", Toast.LENGTH_SHORT).show();
			else if(openCode.equals("1")&& state.equals("1") && positionCode.equals("0"))
				startActivity(new Intent(this, Activity_applyMySchedule.class));
		}

		if(v.getId() == bulletineBoard.getId()){
			if(openCode.equals("1"))
				startActivity(new Intent(this, Activity_bulletin.class));
			else
				Toast.makeText(this, "권한이 없습니다 매니저에게 문의하세요.", Toast.LENGTH_SHORT).show();

		}

		if(v.getId() == enrollmentScedule.getId()){


			if(positionCode.equalsIgnoreCase("1")){
				startActivity(new Intent(this,Activity_scheduleManage.class));
			}//startActivity(new intent)
			else
				Toast.makeText(this, "매니저만 사용 가능합니다.", Toast.LENGTH_SHORT).show();
		}

		if(v.getId() == peopleManageBtn.getId()){
			if(positionCode.equalsIgnoreCase("1"))
				startActivity(new Intent(this, Activity_newPeopleManage.class));
			else
				Toast.makeText(this, "매니저만 사용 가능합니다.", Toast.LENGTH_SHORT).show();
		}
		if(v.getId() == fixSchedule.getId()){

			if(positionCode.equalsIgnoreCase("1"))
				startActivity(new Intent(this, Activity_fixSchedule.class));
			else
				Toast.makeText(this, "매니저만 사용 가능합니다", Toast.LENGTH_SHORT).show();

		}
		if(v.getId() == backBtn.getId())
		{
			if (bExit)
				finish();
			else {
				Toast.makeText(this, "한번 더 누르시면 종료됩니다.",
						Toast.LENGTH_SHORT).show();
				bExit = true;
				new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						bExit = false;
					}
				}, 3 * 1000);
			}
		}


	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/*
	private class idCheckTask extends AsyncTask<String, Integer, Void>{

		private final ProgressDialog dialog = new ProgressDialog(menuActivity.this);
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog.setMessage("Wait a minute.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {
			if(params[0].equals("0")){
				JSONArray idArray = db.requestQuery("select state from location_info where locationCode ='" + locationCode +"';");
				JSONObject json_data;
				try {
					json_data = idArray.getJSONObject(0);
					check = json_data.getString("locationCode");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				int post= 0;
				if(check.equals("0"))
					post = 0;
				if(check.equals("1"))
					post = 1;

				publishProgress(post);
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			if(values[0] == 0)
				check = "0";
			else
				check = "1";
			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();
			super.onPostExecute(result);
		}
	}

	 */
	@Override
	public void onBackPressed() {
		if (bExit)
			finish();
		else {
			Toast.makeText(this, "한번 더 누르시면 종료됩니다.",
					Toast.LENGTH_SHORT).show();
			bExit = true;
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					bExit = false;
				}
			}, 3 * 1000);
		}
	}

	private class getStateTask extends AsyncTask<String, JSONArray, Void>{
		@Override
		protected Void doInBackground(String... params) {


			JSONArray idArray = db.requestQuery("select state from location_info where locationCode = '" + locationCode + "';");
			publishProgress(idArray);

			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {
			// TODO Auto-generated method stub
			try
			{

				JSONObject json_data = values[0].getJSONObject(0);
				state = json_data.getString("state");

			}catch(Exception e)
			{
				Log.e("error",e.getMessage());
			}
		}   
	}

}
