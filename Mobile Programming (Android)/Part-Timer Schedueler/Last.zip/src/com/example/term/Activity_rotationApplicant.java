package com.example.term;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Activity_rotationApplicant extends Activity implements OnClickListener{

	private Button rotBtn;
	private Button okBtn;
	private ListView openList;
	private ListView middleList;
	private ListView closeList;

	private ArrayList<ApplyPerson> applyArr;

	private ArrayList<String> openApplyArr;
	private ArrayList<String> middleApplyArr;
	private ArrayList<String> closeApplyArr;

	private ArrayAdapter<String> openAdapter;
	private ArrayAdapter<String> middleAdapter;
	private ArrayAdapter<String> closeAdapter;

	private DBmanager db;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rotationapplicant);
		getActionBar().hide();
		rotBtn = (Button)findViewById(R.id.rotation_roBtn);
		okBtn = (Button)findViewById(R.id.rotation_okBtn);
		openList = (ListView)findViewById(R.id.rotation_opneList);
		middleList = (ListView)findViewById(R.id.rotation_middleList);
		closeList = (ListView)findViewById(R.id.rotation_closeList);

		rotBtn.setOnClickListener(this);
		okBtn.setOnClickListener(this);

		db = new DBmanager();

		applyArr = new ArrayList<ApplyPerson>();

		openApplyArr  = new ArrayList<String>();
		middleApplyArr  = new ArrayList<String>();
		closeApplyArr  = new ArrayList<String>();

		openAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,openApplyArr );
		middleAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,middleApplyArr );
		closeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,closeApplyArr );

		openList.setAdapter(openAdapter);
		middleList.setAdapter(middleAdapter);
		closeList.setAdapter(closeAdapter);

		//new getApplyPersonTask().execute();
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == rotBtn.getId()){
			openApplyArr.clear(); 
			middleApplyArr.clear();
			closeApplyArr .clear();

			new getApplyPersonTask().execute();
		}
		if(v.getId() == okBtn.getId()){

			new pushApplyPersonTask().execute();

			this.finish();
		}
	}
	private class pushApplyPersonTask extends AsyncTask<String, JSONArray, Void>{

		private final ProgressDialog dialog = new ProgressDialog(Activity_rotationApplicant.this);


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("�옞�떆留� 湲곕떎�젮 二쇱꽭�슂.");
			dialog.show();

			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {

			for(int i=0; i<openApplyArr.size(); i++){
				String query = "insert into fixed_info values ('"+menuActivity.locationCode+"','"+openApplyArr.get(i)+"','"+Activity_fixSchedule.date+"', '"+1+"');" ;
				db.sendQuery(query);
			}
			for(int i=0; i<middleApplyArr.size(); i++){
				String query = "insert into fixed_info values ('"+menuActivity.locationCode+"','"+middleApplyArr.get(i)+"','"+Activity_fixSchedule.date+"', '"+2+"');" ;
				db.sendQuery(query);
			}
			for(int i=0; i<closeApplyArr.size(); i++){
				String query = "insert into fixed_info values ('"+menuActivity.locationCode+"','"+closeApplyArr.get(i)+"','"+Activity_fixSchedule.date+"', '"+3+"');" ;
				db.sendQuery(query);
			}

			publishProgress();
			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {

			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			super.onPostExecute(result);
		}


	}
	private class getApplyPersonTask extends AsyncTask<String, JSONArray, Void>{

		private final ProgressDialog dialog = new ProgressDialog(Activity_rotationApplicant.this);
		String openNum;
		String middleNum;
		String closeNum;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();

			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {

			String query = "select ID, name, applyTime from applytask_info where locationCode = '" + menuActivity.locationCode +"' and workDate = '" + Activity_fixSchedule.date + "';";
			JSONArray one = db.requestQuery(query);


			String query2 = "select openNum, middleNum, closeNum from location_info where locationCode = '" + menuActivity.locationCode +"';";
			JSONArray one2 = db.requestQuery(query2);
			JSONObject json_data2;

			try {
				json_data2 = one2.getJSONObject(0);
				openNum = json_data2.getString("openNum");
				middleNum = json_data2.getString("middleNum");
				closeNum = json_data2.getString("closeNum");

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			publishProgress(one);
			return null;
		}

		@Override
		protected void onProgressUpdate(JSONArray... values) {

			try
			{
				applyArr.clear();
				for(int i=0; i<values[0].length(); i++){

					JSONObject json_data = values[0].getJSONObject(i);
					String ID = json_data.getString("ID");
					String name= json_data.getString("name");
					String applyTime = json_data.getString("applyTime");
					applyArr.add(new ApplyPerson(ID,name,applyTime));
				}


				int open = Integer.parseInt(openNum);
				int middle = Integer.parseInt(middleNum);
				int close = Integer.parseInt(closeNum);

				int checkOpen, checkMiddle, checkClose;
				checkOpen = checkMiddle = checkClose = 0;
				int getSize = applyArr.size();
				int changeSize = applyArr.size();
				Log.d("TT",""+getSize);
				
				for(int i=0; i<getSize; i++){
					
					int random = 0;
					random = (int)(Math.random() *1000) % changeSize;
					Log.d("TT",""+changeSize+" / "+random);
					if( checkOpen == open && checkMiddle == middle & checkClose == close){
						break;
					}
					
					
					if(applyArr.get(random).getApplyTime().equals("123")){

						if(checkOpen < open && checkMiddle < middle && checkClose < close){
							int rnd = (int)(Math.random() * 10) % 3;
							if(rnd == 0){
								checkOpen++;
								openApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else if(rnd == 1){
								checkMiddle++;
								middleApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else if(rnd == 2){
								checkClose++;
								closeApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkOpen >= open && checkMiddle < middle && checkClose < close){
							int rnd = (int)(Math.random() * 10) % 2;
							if(rnd == 0){
								checkMiddle++;
								middleApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;

							}else if(rnd == 1){
								checkClose++;
								closeApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkOpen < open && checkMiddle >= middle && checkClose < close){
							int rnd = (int)(Math.random() * 10) % 2;
							if(rnd == 0){
								checkOpen++;
								openApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else if(rnd == 1){
								checkClose++;
								closeApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkOpen < open && checkMiddle < middle && checkClose >= close){
							int rnd = (int)(Math.random() * 10) % 2;

							if(rnd == 0){
								checkOpen++;
								openApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else if(rnd == 1){
								checkMiddle++;
								middleApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;

							}
						}else if(checkOpen < open && checkMiddle >= middle && checkClose >= close){
							checkOpen++;
							openApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}else if(checkOpen >= open && checkMiddle < middle && checkClose >= close){
							checkMiddle++;
							middleApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}else if(checkOpen >= open && checkMiddle >= middle && checkClose < close){
							checkClose++;
							closeApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
						//--------------------------------------------
					}else if(applyArr.get(random).getApplyTime().equals("13")){
						if(checkOpen < open && checkClose < close){
							int rnd = (int)(Math.random() * 10) % 2;

							if(rnd == 0){
								checkOpen++;
								openApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else{
								checkClose++;
								closeApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkOpen >= open && checkClose < close){
							checkClose++;
							closeApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}else if(checkOpen < open && checkClose >= close){
							checkOpen++;
							openApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}

						//-----------------------------------------------
					}else if(applyArr.get(random).getApplyTime().equals("12")){
						if(checkOpen < open && checkMiddle < middle){
							int rnd = (int)(Math.random() * 10) % 2;

							if(rnd == 0){
								checkOpen++;
								openApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else{
								checkMiddle++;
								middleApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkOpen < open && checkMiddle >= middle){
							checkOpen++;
							openApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}else if(checkOpen >= open && checkMiddle < middle){
							checkMiddle++;
							middleApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
					}else if(applyArr.get(random).getApplyTime().equals("1")){
						if(checkOpen < open){
							checkOpen++;
							openApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
					}else if(applyArr.get(random).getApplyTime().equals("2")){
						if(checkMiddle < middle){
							checkMiddle++;
							middleApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
					}else if(applyArr.get(random).getApplyTime().equals("3")){
						if(checkClose < close){
							checkClose++;
							closeApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
					}else if(applyArr.get(random).getApplyTime().equals("23")){
						if(checkMiddle < middle && checkClose < close){
							int rnd = (int)(Math.random() * 10) % 2;

							if(rnd == 0){
								checkMiddle++;
								middleApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}else{
								checkClose++;
								closeApplyArr.add(applyArr.get(random).getName());
								applyArr.remove(random);
								changeSize--;
							}
						}else if(checkMiddle < middle && checkClose >= close){
							checkMiddle++;
							middleApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}else if(checkMiddle >= middle && checkClose < close){
							checkClose++;
							closeApplyArr.add(applyArr.get(random).getName());
							applyArr.remove(random);
							changeSize--;
						}
					}
				}


			}catch(Exception e){
				Log.e("error",e.getMessage());
			}

			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			openAdapter.notifyDataSetChanged();
			middleAdapter.notifyDataSetChanged();
			closeAdapter.notifyDataSetChanged();
			super.onPostExecute(result);
		}


	}


}