package com.example.term;

public class ApplyPerson {

	private String ID;
	private String name;
	private String applyTime;
	
	public ApplyPerson(String newID, String newname, String newApplyTime)
	{
		ID = newID;
		name = newname;
		applyTime = newApplyTime;
	}
	
	public String getID()
	{
		return ID;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getApplyTime()
	{
		return applyTime;
	}
	
	public void setID(String newID)
	{
		ID = newID;
	}
	
	public void setName(String newname)
	{
		name = newname;
	}
	
	public void setApplyTime(String newApplyTime)
	{
		applyTime = newApplyTime;
	}
}
