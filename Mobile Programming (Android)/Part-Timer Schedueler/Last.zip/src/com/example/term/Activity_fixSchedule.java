package com.example.term;

import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;

public class Activity_fixSchedule extends Activity implements OnClickListener{

   private Button catalBtn, showFixMemBtn;


   private static ArrayList<String> applicantOpen;
   private static ArrayList<String> applicantMiddle;
   private static ArrayList<String> applicantClose;


   private ListView applicantOpenView;
   private ListView applicantMiddleView;
   private ListView applicantCloseView;
   private TextView openText;
   private TextView middleText;
   private TextView closeText;
   private TextView dateText;

   private ArrayAdapter<String> openAdapter;
   private ArrayAdapter<String> middleAdapter;
   private ArrayAdapter<String> closeAdapter;

   public static String date;

   private final int DIALOG_DATE = 1;

   private DBmanager db;


   @Override
   protected void onCreate(Bundle savedInstanceState) {
      setContentView(R.layout.activity_fixschedule);
      getActionBar().hide();
      catalBtn = (Button)findViewById(R.id.fixScedule_showCatalogBtn);
      showFixMemBtn = (Button)findViewById(R.id.fixScedule_showfixmemberList);
      
      applicantOpenView = (ListView)findViewById(R.id.fixScedule_open);
      applicantMiddleView = (ListView)findViewById(R.id.fixScedule_middle);
      applicantCloseView = (ListView)findViewById(R.id.fixScedule_close);
      
      openText = (TextView)findViewById(R.id.fix_textView1);
      middleText = (TextView)findViewById(R.id.fix_textView2);
      closeText = (TextView)findViewById(R.id.fix_textView3);
      dateText = (TextView)findViewById(R.id.fixSchedule_dateText);


      db = new DBmanager();

      applicantOpen = new ArrayList<String>();
      applicantMiddle = new ArrayList<String>();
      applicantClose = new ArrayList<String>();

      openAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,applicantOpen);
      middleAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,applicantMiddle);
      closeAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,applicantClose);

      applicantOpenView.setAdapter(openAdapter);
      applicantMiddleView.setAdapter(middleAdapter);
      applicantCloseView.setAdapter(closeAdapter);

      catalBtn.setOnClickListener(this);
      showFixMemBtn.setOnClickListener(this);

      super.onCreate(savedInstanceState);
   }

   @Override
   public void onClick(View v) {

      switch(v.getId()){
      case R.id.fixScedule_showCatalogBtn:
         showDialog(DIALOG_DATE);
         break;
      case R.id.fixScedule_showfixmemberList:
         startActivityForResult(new Intent(this, Activity_rotationApplicant.class), 100);
      }
   }
   
   
   @Override
   protected void onActivityResult(int requestCode, int resultCode, Intent data) {
      // TODO Auto-generated method stub
      super.onActivityResult(requestCode, resultCode, data);
   }


   @Override
   protected Dialog onCreateDialog(int id) {

      Date one = new Date();

      if(id == DIALOG_DATE)   
         return new DatePickerDialog(this, dateListener,2015,5,1);

      return null;
   }

   private DatePickerDialog.OnDateSetListener dateListener = 
         new DatePickerDialog.OnDateSetListener() {

      @Override
      public void onDateSet(DatePicker view, int year, int monthOfYear,
            int dayOfMonth) {

         date = year+"-"+(monthOfYear+1)+"-"+dayOfMonth;
         dateText.setText(date);

         new getApplyMember().execute(menuActivity.locationCode,date);
      }
   };
   
   public void rotationList()
   {
      
      
   }

   private class getApplyMember extends AsyncTask<String, JSONArray, Void>{

      private final ProgressDialog dialog = new ProgressDialog(Activity_fixSchedule.this);

      @Override
      protected void onPreExecute() {
         // TODO Auto-generated method stub

         dialog.setMessage("잠시만 기다려 주세요.");
         dialog.show();
         super.onPreExecute();
      }

      @Override
      protected Void doInBackground(String... params) {

         String locationCode = params[0];
         String workDate = params[1];

         String query = "select ID, name, applyTime from applytask_info where locationCode = '" + locationCode + "' and workDate = '" + workDate +"';";

         JSONArray one = db.requestQuery(query);

         publishProgress(one);
         return null;
      }

      @Override
      protected void onProgressUpdate(JSONArray... values) {
         // TODO Auto-generated method stub

         Log.e("error","ㅁㅁㅁㅁㅁㅁㅁㅁlength : " + values[0].length());

         try
         {

            applicantOpen.clear();
            applicantMiddle.clear();
            applicantClose.clear();
            
            for(int i=0; i<values[0].length(); i++)
            {
         
               JSONObject json_data = values[0].getJSONObject(i);

               String ID = json_data.getString("ID");
               String name = json_data.getString("name");
               String applyTime = json_data.getString("applyTime");

               if(applyTime.contains("1"))
                  applicantOpen.add("ID : " + ID + "Name : " + name);
               if(applyTime.contains("2"))
                  applicantMiddle.add("ID : " + ID + "Name : " + name);
               if(applyTime.contains("3"))
                  applicantClose.add("ID : " + ID + "Name : " + name);
            }
            
            openText.setText("Open Time applyer : " + applicantOpen.size());
            middleText.setText("Middle Time applyer: " + applicantMiddle.size());
            closeText.setText("Close Time applyer : " + applicantClose.size());
            

            openAdapter.notifyDataSetChanged();
            middleAdapter.notifyDataSetChanged();
            closeAdapter.notifyDataSetChanged();

         }catch(Exception e)
         {
            Log.e("error",e.getMessage());
         }

         super.onProgressUpdate(values);

      }

      @Override
      protected void onPostExecute(Void result) {

         if(dialog.isShowing())
            dialog.dismiss();

         super.onPostExecute(result);
      }
   }
}