package com.example.term;

import java.util.ArrayList;






import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CustomAdapter extends BaseAdapter{

	private ArrayList<String> name_List;
	private Context context = null;;
	private OnClickListener myOnClickListener = null;



	public CustomAdapter()
	{
		name_List = new ArrayList<String>();
	}
	
	public CustomAdapter(OnClickListener onClickListener)
	{
		name_List = new ArrayList<String>();
		myOnClickListener = onClickListener;
	}


	@Override
	public int getCount() {
		return name_List.size();
	}

	@Override
	public Object getItem(int position) {
		return name_List.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final int pos = position;
		context = parent.getContext();

		TextView text = null;
		Button acceptBtn = null;
		Button rejectBtn = null;
		CustomHolder holder = null;
		
		String[] result = name_List.get(position).split(" ");
		String ID = result[0];
		String name = result[1];
		String openCode = result[2];
		
		// 리스트가 길어지면서 현재 화면에 보이지 않는 아이템은 converView가 null인 상태로 들어 옴
		if ( convertView == null ) {
			// view가 null일 경우 커스텀 레이아웃을 얻어 옴
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.customadapter_item, parent, false);

			// TextView에 현재 position의 문자열 추가
			text = (TextView) convertView.findViewById(R.id.nameText);
			acceptBtn = (Button) convertView.findViewById(R.id.acceptButton);
			rejectBtn = (Button) convertView.findViewById(R.id.rejectButton);

			holder = new CustomHolder();
			holder.m_TextView   = text;
			holder.ok_Btn        = acceptBtn;
			holder.cancle_Btn = rejectBtn;
		
			if(openCode.equals("1"))
				holder.ok_Btn.setEnabled(false);
			
			convertView.setTag(holder);
			holder.ok_Btn.setTag(pos);
			holder.cancle_Btn.setTag(pos);
		}
		else
		{
			holder  = (CustomHolder) convertView.getTag();
			text    = holder.m_TextView;
			acceptBtn = holder.ok_Btn;
			rejectBtn = holder.cancle_Btn;
			
			acceptBtn.setTag(pos);
			rejectBtn.setTag(pos);
			
			if(openCode.equals("1"))
				acceptBtn.setEnabled(false);
		

		}
		text.setText("ID : " + ID + " Name : " + name);

		acceptBtn.setOnClickListener(myOnClickListener);
		rejectBtn.setOnClickListener(myOnClickListener);
	
		return convertView;
	}

	public void add(String name)
	{
		name_List.add(name);
	}

	public void remove(int position)
	{
		name_List.remove(position);
	}

	private class CustomHolder{
		TextView m_TextView;
		Button ok_Btn;
		Button cancle_Btn;
	}

	
}
