package com.example.term;

import org.json.JSONArray;





import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_enrollment extends Activity implements OnClickListener {

	private EditText idEdit;
	private EditText passEdit;
	private EditText nameEdit;
	private EditText locationEdit;
	private EditText passReCheckEdit;
	private RadioGroup radioGroup;
	private RadioButton radioTimer;
	private RadioButton radioManager;
	private   Button dupliBtn;
	private Button okBtn;
	private Button dupliLocationBtn;
	private DBmanager db;
	private Spinner mySpinner;
	private ArrayAdapter myAdapter;
	private boolean idCheck;
	private boolean locationCheck;
	private String locationList[] = {"0","1"};
	private String templocation;

	String positionCode = null;
	private String tempLocation;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_enrollment);

		getActionBar().hide();

		idEdit = (EditText)findViewById(R.id.idEditText);
		passEdit = (EditText)findViewById(R.id.passEditText);
		nameEdit = (EditText)findViewById(R.id.nameEditText);
		locationEdit = (EditText)findViewById(R.id.locationEditText);
		passReCheckEdit = (EditText)findViewById(R.id.passEditText2);
		dupliLocationBtn = (Button)findViewById(R.id.shopCheckBtn);

		radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
		radioTimer = (RadioButton)findViewById(R.id.radioBtnTimer);
		radioManager = (RadioButton)findViewById(R.id.radioBtnManager);

		dupliBtn = (Button)findViewById(R.id.idCheckButton);

		okBtn = (Button)findViewById(R.id.OKButton9);
		//mySpinner = (Spinner)findViewById(R.id.spinner1);

		myAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,locationList);

		//mySpinner.setAdapter(myAdapter);

		db = new DBmanager();

		dupliBtn.setOnClickListener(this);
		okBtn.setOnClickListener(this);
		dupliLocationBtn.setOnClickListener(this);
		//mySpinner.setOnItemSelectedListener(this);

	}

	@Override
	public void onClick(View v) {

		if(v.getId() == dupliBtn.getId())
		{
			String tempId = idEdit.getText().toString();

			if(tempId.length() == 0)
				Toast.makeText(this, "ID를 입력해 주세요", Toast.LENGTH_SHORT).show();
			else
				new idCheckTask().execute(idEdit.getText().toString());
		}
		else if(v.getId() == dupliLocationBtn.getId())
		{

			tempLocation = locationEdit.getText().toString();

			if(radioTimer.isChecked() && locationEdit.getText().toString().length() != 0)
				new locationCheckTask().execute("0",locationEdit.getText().toString());
			else if(radioManager.isChecked()&& locationEdit.getText().toString().length() != 0)
				new locationCheckTask().execute("1",locationEdit.getText().toString());
			else if(radioManager.isChecked() == false && radioTimer.isChecked() == false)
				Toast.makeText(this, "가입자 type을 선택해 주세요.", Toast.LENGTH_SHORT).show();
			else
				Toast.makeText(this, "지역 code를 입력해 주세요.", Toast.LENGTH_SHORT).show();


		}
		else if(v.getId() == okBtn.getId())
		{
			if(idEdit.getText().toString().length() == 0 && passEdit.getText().toString().length() == 0 &&
					nameEdit.length() == 0 && (radioTimer.isChecked() || radioManager.isChecked()))
				Toast.makeText(this, "모든 정보를 입력해주세요", Toast.LENGTH_SHORT).show();
			else if(passEdit.getText().toString().equalsIgnoreCase(passReCheckEdit.getText().toString()) == false)
			{
				Toast.makeText(this, "비밀번호를 확인해 주세요", Toast.LENGTH_SHORT).show();
			}
			else
			{
				if(idCheck == false)
					Toast.makeText(this, "ID 중복확인을 해주세요", Toast.LENGTH_SHORT).show();
				else if(locationCheck == false)
					Toast.makeText(this, "지역Code 중복확인을 해주세요", Toast.LENGTH_SHORT).show();
				else
				{
					if(tempLocation.equals(locationEdit.getText().toString())){

						if(radioTimer.isChecked())
							positionCode = "0";
						else if(radioManager.isChecked())
							positionCode = "1";

						String id = idEdit.getText().toString();
						String pass = passEdit.getText().toString();
						String name = nameEdit.getText().toString();
						String locationCode = locationEdit.getText().toString();
						String openCode = "0";
						
						String query;
						
						if(positionCode.equals("0"))
							 query = "insert into member_info values('"+ id +"','" + pass + "','" + name + "','" + locationCode + "','" + positionCode + "','" + openCode +"');";
						else
							 query = "insert into member_info values('"+ id +"','" + pass + "','" + name + "','" + locationCode + "','" + positionCode + "','" + openCode +"','" + 1 +"');";


						new applyEnrollmentTask().execute(query,locationCode, positionCode);
					}
					else
						Toast.makeText(this, "지역Code 중복확인을 해주세요", Toast.LENGTH_SHORT).show();
				}
			}
		}
	}

	private class applyEnrollmentTask extends AsyncTask<String, Boolean,Void>
	{
		private final ProgressDialog dialog = new ProgressDialog(Activity_enrollment.this);
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {

			boolean check1 = false;
			boolean check2 = false;

			if(params[2].equalsIgnoreCase("1"))
			{
				String query = "insert into location_info values('" + params[1] + "','0','0','0','0','0','0');";

				check2 = db.sendQuery(query);
			}

			check1 = db.sendQuery(params[0]);
			if(positionCode.equals("1")){
				check1 = !check1;
				check2 = !check2;
			}
			Log.d("1"+check1 , "2"+ check2);
			publishProgress(!(check2 && check1));

			return null;
		}
		@Override
		protected void onProgressUpdate(Boolean... values) {

			if(values[0] == true)
			{
				Toast.makeText(getApplicationContext(), "가입이 완료되었습니다", Toast.LENGTH_SHORT).show();
				finish();
			}
			else
			{
				Toast.makeText(getApplicationContext(), "다시 시도해 주세요", Toast.LENGTH_SHORT).show();
			}


			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();


			super.onPostExecute(result);
		}

	}




	private class idCheckTask extends AsyncTask<String, Integer, Void>{

		private final ProgressDialog dialog = new ProgressDialog(Activity_enrollment.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {

			JSONArray idArray = db.requestQuery("select ID from member_info where ID ='" + params[0] +"';");

			publishProgress(idArray.length());


			return null;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {

			if(values[0] == 0)
			{
				Toast.makeText(getApplicationContext(), "사용할수 있는 ID 입니다", Toast.LENGTH_SHORT).show();
				idCheck = true;
			}
			else
				Toast.makeText(getApplicationContext(), "중복되는 ID 입니다", Toast.LENGTH_SHORT).show();

			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();


			super.onPostExecute(result);
		}
	}


	private class locationCheckTask extends AsyncTask<String, String, Void>{

		private final ProgressDialog dialog = new ProgressDialog(Activity_enrollment.this);
		private int arrLength;


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {

			JSONArray idArray = db.requestQuery("select locationCode from location_info where locationCode = '" + params[1] + "';");

			Log.e("error","type : " + params[0]);
			Log.e("error","code : " + params[1]);
			Log.e("error","length : " + idArray.length());

			arrLength = idArray.length();
			publishProgress(params[0]);


			return null;
		}


		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub

			if(values[0].equalsIgnoreCase("0") && arrLength > 0)
			{
				Toast.makeText(getApplicationContext(), "사용 가능한 Code 입니다", Toast.LENGTH_LONG).show();
				locationCheck = true;
			}
			else if(values[0].equalsIgnoreCase("0") && arrLength == 0)
				Toast.makeText(getApplicationContext(), "존재하지 않는 Code 입니다", Toast.LENGTH_LONG).show();
			else if(values[0].equalsIgnoreCase("1") && arrLength == 0)
			{
				Toast.makeText(getApplicationContext(), "사용 가능한 Code 입니다", Toast.LENGTH_LONG).show();
				locationCheck = true;
			}
			else if(values[0].equalsIgnoreCase("1") && arrLength > 0)
				Toast.makeText(getApplicationContext(), "중복되는 Code 입니다", Toast.LENGTH_LONG).show();



			super.onProgressUpdate(values);
		}
		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();


			super.onPostExecute(result);
		}
	}



}