package com.example.term;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {


	private TextView text;
	private DBmanager db;

	private Intent myIntent;


	private EditText idEdit;
	private EditText passEdit;
	private String id;
	private String pass;
	private Button logBtn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		startActivity(new Intent("com.example.term.splash"));

		getActionBar().hide();

		db = new DBmanager();

		idEdit = (EditText)findViewById(R.id.editID);
		passEdit = (EditText)findViewById(R.id.editPasswrod);
		logBtn = (Button)findViewById(R.id.buttonLogin);
		text = (TextView)findViewById(R.id.newMember);

		logBtn.setOnClickListener(this);
		text.setOnClickListener(this);

	}

	public void menuClick(View v){
		startActivity(new Intent("com.example.term.menuActivity"));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {

		if(v.getId() == text.getId())
		{
			startActivity(new Intent(this,Activity_enrollment.class));
		}
		else if(v.getId() == logBtn.getId() )
		{

			id = idEdit.getText().toString();
			pass = passEdit.getText().toString();

			if(id.length() == 0 || pass.length() == 0)
				Toast.makeText(this, "ID & PASSWORD Reinput", Toast.LENGTH_SHORT).show();
			else
			{
				String query = "select * from member_info where ID = '" + id + "'and pass ='" + pass + "';";
				new loginCheckTask().execute(query);
			}

		}
	}

	private class loginCheckTask extends AsyncTask<String, JSONArray, Void>{

		private final ProgressDialog dialog = new ProgressDialog(MainActivity.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("로그인 중입니다.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {


			JSONArray idArray = db.requestQuery(params[0]);

			publishProgress(idArray);

			return null;
		}


		@Override
		protected void onProgressUpdate(JSONArray... values) {
			// TODO Auto-generated method stub

			if(values[0].length() == 0)
				Toast.makeText(getApplicationContext(), "Please check your ID & Password.", Toast.LENGTH_SHORT).show();
			else
			{
				Person myInfo;
				try
				{

					JSONObject json_data = values[0].getJSONObject(0);

					String Name = json_data.getString("name");
					String ID= json_data.getString("ID");
					String password = json_data.getString("pass");
					String positionCode = json_data.getString("positionCode");
					String locationCode = json_data.getString("locationCode");
					String openCode = json_data.getString("openCode");

					myInfo = new Person(ID,password,Name,locationCode,positionCode, openCode);


					Bundle myInfoBundle = new Bundle();

					myInfoBundle.putSerializable("myInfo", myInfo);

					Intent myIntent = new Intent("com.example.term.menuActivity");      
					myIntent.putExtras(myInfoBundle);

					startActivity(myIntent);

					Toast.makeText(getApplicationContext(), Name + "님 환영합니다.", Toast.LENGTH_SHORT).show();
					finish();

				}catch(Exception e)
				{
					Log.e("error",e.getMessage());
				}
			}   
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();


			super.onPostExecute(result);
		}
	}
	
	
}