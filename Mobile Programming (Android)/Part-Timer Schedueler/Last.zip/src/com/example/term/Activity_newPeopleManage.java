package com.example.term;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class Activity_newPeopleManage extends Activity implements OnClickListener, OnItemClickListener{

	private ListView myListView;
	private CustomAdapter myAdapter;
	private DBmanager db;
	private int pos;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Log.e("error","]]]]]]]]]]]]]]]]]");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_newpeoplemanage);
		getActionBar().hide();
		myListView = (ListView)findViewById(R.id.peopleListView);
		myListView.setOnItemClickListener(this);
		Log.e("error","1");

		myAdapter = new CustomAdapter(this);
		myListView.setAdapter(myAdapter);

		db = new DBmanager();

		new getMyPeopleTask().execute();


		Log.e("error","4");
	}

	private class getMyPeopleTask extends AsyncTask<String, JSONArray, Void>
	{

		private final ProgressDialog dialog = new ProgressDialog(Activity_newPeopleManage.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {

			String myLocationCode = menuActivity.locationCode;
			Log.e("error","eeeeee" + myLocationCode);
			String query = "select ID, name, openCode from member_info where locationCode = '" + myLocationCode + "' and positionCode = '0';";
			Log.e("error",query);
			JSONArray myPeopleArr = db.requestQuery(query);
			publishProgress(myPeopleArr);

			return null;
		}
		@Override
		protected void onProgressUpdate(JSONArray... values) {

			try
			{
				for(int i=0; i<values[0].length(); i++)
				{
					JSONObject json_data = values[0].getJSONObject(i);

					String ID = json_data.getString("ID");
					String name = json_data.getString("name");
					String openCode = json_data.getString("openCode");

					Log.e("error","dd : "+ "ID : " + ID + " Name : " + name);

					myAdapter.add(ID +" " +name + " " + openCode);
				}
			}catch(Exception e)
			{
				Log.e("error",e.getMessage());
			}	

			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();


			super.onPostExecute(result);
		}

	}

	private class acceptMemberTask extends AsyncTask<String, Void, Void>
	{

		DBmanager db = new DBmanager();
		private final ProgressDialog dialog = new ProgressDialog(Activity_newPeopleManage.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {


			String[] result = params[0].split(" ");
			String ID = result[0];
			String name = result[1];

			String query = "update member_info set openCode = '1' where ID = '" + ID + "' and name = '" + name + "';";

			if(db.sendQuery(query))
				Log.e("error","쿼리 잘보냄");
			else
			{
				Log.e("error","쿼리 잘못보냄");
			}

			return null;
		}

		@Override
		protected void onProgressUpdate(Void... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
		}


		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			Toast.makeText(getApplicationContext(), "수락 되었습니다"	, Toast.LENGTH_SHORT).show();


			super.onPostExecute(result);
		}
	}
	private class rejectMemberTask extends AsyncTask<String, Void, Void>
	{
		DBmanager db = new DBmanager();
		private final ProgressDialog dialog = new ProgressDialog(Activity_newPeopleManage.this);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			dialog.setMessage("잠시만 기다려 주세요.");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... params) {

			String[] result = params[0].split(" ");
			String ID = result[0];
			String name = result[1];

			String query = "delete from member_info where ID = '" + ID + "' and name = '" + name +"';";

			if(db.sendQuery(query))
				Log.e("error","쿼리 잘보냄dd");
			else
			{
				Log.e("error","쿼리 잘못보냄dd");
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {

			if(dialog.isShowing())
				dialog.dismiss();

			Toast.makeText(getApplicationContext(), "삭제 되었습니다"	, Toast.LENGTH_SHORT).show();

			super.onPostExecute(result);
		}

	}
	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.acceptButton)
		{
			int pos = (Integer)v.getTag();

			new acceptMemberTask().execute((String)myAdapter.getItem((pos)));
			Button btn = (Button)findViewById(R.id.acceptButton);
			btn.setEnabled(false);


		}
		if(v.getId() == R.id.rejectButton)
		{
			int pos = (Integer)v.getTag();

			new rejectMemberTask().execute((String)myAdapter.getItem(pos));
			myAdapter.remove(pos);
			myAdapter.notifyDataSetChanged();
		}
	}


	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {

		pos = position;

		// TODO Auto-generated method stub

	}
}
