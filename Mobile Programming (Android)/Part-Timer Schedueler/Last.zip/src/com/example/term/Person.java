package com.example.term;

import java.io.Serializable;

public class Person implements Serializable{
	
	private String id;
	private String password;
	private String name;
	private String locationCode;
	private String positionCode;
	private String openCode;
	
	public Person()
	{
		
	}
	
	public Person(String id, String password, String name, String locationCode, String code, String openCode)
	{
		this.id = id;
		this.password = password;
		this.name = name;
		this.locationCode = locationCode;
		this.positionCode = code;
		this.openCode = openCode;
	}
	
	public void setId(String newId)
	{
		id = newId;
	}
	
	public void setPassword(String newPassword)
	{
		password = newPassword;
	}
	
	public void setName(String newName)
	{
		name = newName;
	}
	
	public void setLocationCode(String code)
	{
		locationCode = code;
	}
	
	public void setPositionCode(String newCode)
	{
		positionCode = newCode;
	}
	
	public void setOpenCode(String openCode)
	{
		this.openCode = openCode;
	}
	
	public String getOpenCode()
	{
		return openCode;
	}
	
	public String getId()
	{
		return id;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getLocationCode()
	{
		return locationCode;
	}
	
	public String getCode()
	{
		return positionCode;
	}

}
