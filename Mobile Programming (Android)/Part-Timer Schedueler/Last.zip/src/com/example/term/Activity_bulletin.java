package com.example.term;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
 
public class Activity_bulletin extends Activity implements OnClickListener{
     
    private WebView mWebView;
    private Button backButton;
     
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      
        setContentView(R.layout.activity_bulletin);
        
        getActionBar().hide();
        backButton = (Button)findViewById(R.id.homeButton);
        mWebView = (WebView)findViewById(R.id.webView);
        
        backButton.setOnClickListener(this);
 
        // �쎒酉곗뿉�꽌 �옄諛붿뒪�겕由쏀듃�떎�뻾媛��뒫
        mWebView.getSettings().setJavaScriptEnabled(true); 
        // 援ш��솃�럹�씠吏� 吏��젙
        mWebView.loadUrl("http://kyl1436.dothome.co.kr/xe/freeboard");
     
        // WebViewClient 吏��젙
        mWebView.setWebViewClient(new WebViewClientClass());  
    
         
    }
    
    @Override
    public void onBackPressed() {
       // TODO Auto-generated method stub
    //   super.onBackPressed();
       mWebView.goBack();
    }
     
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { 
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) { 
            mWebView.goBack(); 
            return true; 
        } 
        return super.onKeyDown(keyCode, event);
    }
     
    private class WebViewClientClass extends WebViewClient { 
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) { 
            view.loadUrl(url); 
            return true; 
        } 
    }

   @Override
   public void onClick(View v) {
      finish();
   }
    
 
}