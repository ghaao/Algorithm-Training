//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mfcgl.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MFCGLTYPE                   129
#define IDD_SCALEDLG                    130
#define IDD_DIALOG_SET                  131
#define IDD_STATICX                     1000
#define IDC_EDIT_X                      1001
#define IDD_STATICY                     1002
#define IDD_STATICZ                     1003
#define IDC_EDIT_Y                      1004
#define IDC_EDIT_Z                      1005
#define IDC_STATIC_CAMERA               1007
#define IDC_STATIC_DOLLY                1008
#define IDC_BUTTON_DOLLYP               1009
#define IDC_BUTTON_DOLLYM               1010
#define IDC_STATIC_ZOOM                 1012
#define IDC_BUTTON_ZOOMP                1013
#define IDC_BUTTON_ZOOMM                1014
#define IDC_STATIC_PAN                  1015
#define IDC_BUTTON_PANP                 1016
#define IDC_BUTTON_PANM                 1017
#define IDC_BUTTON_TUMBLEP              1018
#define IDC_BUTTON_TUMBLEM              1019
#define IDC_BUTTON_TILTP                1020
#define IDC_BUTTON_TILTM                1021
#define IDC_BUTTON_HEIGHTP              1022
#define IDC_BUTTON_HEIGHTM              1023
#define IDC_STATIC_TUMBLE               1028
#define IDC_STATIC_TILT                 1029
#define IDC_STATIC_HEIGHT               1030
#define IDC_STATIC_TRANSFORM            1031
#define IDC_STATIC_X                    1032
#define IDC_STATIC_Y                    1033
#define IDC_STATIC_Z                    1034
#define IDC_STATIC_TRANSLATION          1035
#define IDC_BUTTON_TXP                  1036
#define IDC_BUTTON_TXM                  1037
#define IDC_BUTTON_TYP                  1038
#define IDC_BUTTON_TYM                  1039
#define IDC_BUTTON_TZP                  1040
#define IDC_BUTTON_TZM                  1041
#define IDC_EDIT_AL                     1042
#define IDC_EDIT_DL                     1043
#define IDC_EDIT_SL                     1044
#define IDC_STATIC_X2                   1045
#define IDC_STATIC_Y2                   1046
#define IDC_STATIC_Z2                   1047
#define IDC_BUTTON_RXP                  1048
#define IDC_BUTTON_RXM                  1049
#define IDC_BUTTON_RYP                  1050
#define IDC_BUTTON_RYM                  1051
#define IDC_BUTTON_RZP                  1052
#define IDC_BUTTON_RZM                  1053
#define IDC_BUTTON_SXP                  1054
#define IDC_BUTTON_SXM                  1055
#define IDC_BUTTON_SYP                  1056
#define IDC_BUTTON_SYM                  1057
#define IDC_BUTTON_SZP                  1058
#define IDC_BUTTON_SZM                  1059
#define IDC_BUTTON_ALP                  1060
#define IDC_BUTTON_ALM                  1061
#define IDC_BUTTON_DLP                  1062
#define IDC_BUTTON_DLM                  1063
#define IDC_BUTTON_SLP                  1064
#define IDC_BUTTON_SLM                  1065
#define IDC_BUTTON_LPXP                 1066
#define IDC_BUTTON_LPXM                 1067
#define IDC_BUTTON_LPYP                 1068
#define IDC_BUTTON_LPYM                 1069
#define IDC_BUTTON_LPZP                 1070
#define IDC_BUTTON_LPZM                 1071
#define IDC_EDIT1                       1072
#define IDC_STATIC_TRANSLATION2         1073
#define IDC_STATIC_TRANSLATION3         1074
#define IDC_EDIT_LPX                    1075
#define IDC_EDIT_LPY                    1076
#define IDC_EDIT_LPZ                    1077
#define IDC_EDIT2                       1078
#define ID_BUTTON_MOVE                  32773
#define ID_BUTTON_ROTA                  32774
#define ID_BUTTON_SCALE                 32775
#define ID_MENUITEM32785                32785
#define ID_BUTTON_DOLLY                 32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1079
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
