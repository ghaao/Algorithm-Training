// ScaleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mfcgl.h"
#include "ScaleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScaleDlg dialog


CScaleDlg::CScaleDlg(CWnd* pParent /*=NULL*/)
: CDialog(CScaleDlg::IDD, pParent)
{
	x_Scale=1.0f;
	y_Scale=1.0f;
	z_Scale=1.0f;
	
}


void CScaleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_X,x_Scale);
	DDX_Text(pDX, IDC_EDIT_Y,y_Scale);
	DDX_Text(pDX, IDC_EDIT_Z,z_Scale);
}


BEGIN_MESSAGE_MAP(CScaleDlg, CDialog)
	//{{AFX_MSG_MAP(CScaleDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScaleDlg message handlers
