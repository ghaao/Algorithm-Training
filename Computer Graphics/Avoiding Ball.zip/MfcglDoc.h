// MfcglDoc.h : interface of the CMfcglDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFCGLDOC_H__7EC37B50_F7FD_44A2_BD93_70C266288BEF__INCLUDED_)
#define AFX_MFCGLDOC_H__7EC37B50_F7FD_44A2_BD93_70C266288BEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMfcglDoc : public CDocument
{
protected: // create from serialization only
	CMfcglDoc();
	DECLARE_DYNCREATE(CMfcglDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcglDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMfcglDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMfcglDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCGLDOC_H__7EC37B50_F7FD_44A2_BD93_70C266288BEF__INCLUDED_)
