// MfcglView.h : interface of the CMfcglView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFCGLVIEW_H__A3DD22F6_EDEE_471B_ADA2_74D2BCA0C178__INCLUDED_)
#define AFX_MFCGLVIEW_H__A3DD22F6_EDEE_471B_ADA2_74D2BCA0C178__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMfcglView : public CView
{
protected: // create from serialization only
	CMfcglView();
	DECLARE_DYNCREATE(CMfcglView)

// Attributes
public:
	CMfcglDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcglView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	double head_Base;
	int R_head;
	int R_stage;
	void drawcone_nocolor();
	CString realtime;
	void face_mouth();
	void face_eye();
	double B_Rotate;
	void drawcone();
	void CheckGameState();
	void head(int ShadowCheck);
	void leftarm(int ShadowCheck);
	void rightarm(int ShadowCheck);
	void body(int ShadowCheck);
	void leftleg(int ShadowCheck);
	void rightleg(int ShadowCheck);
	void drawwall(int x);
	GLUquadricObj *p;
	double leg_Base, arm_Base;//right_Base, left_Base, left_Arm, right_Arm;
	GLubyte* read_texturemapping_img(const char *filename, BITMAPINFO **info);
	void drawground();
	void r_drawball(int temp, double z, double time, int n);
	void drawball(double x_B, double z_B, int n);
	void drawCharacter(double arm_Base, double leg_Base, double head_Base, int ShadowCheck);
	void CalcShadowMat(float* xyz, double* mat);
	void drawShadow();
	void drawcenter();
	void calcNomal(float v[3][3],float out[3]);
	void ReduceToUnit(float vector[3]);
	void Light();
	void LingtR();
	void myglWireCube();
	double z_B, z_B1, z_B2, z_B3, z_B4, z_B5;	//���� z ��
	double z_C, x_C;
	int R_leg, R_arm;		//�߰� �ٸ��� ������ ���� ��
	double speedadd;	//���� �ӵ��߰� ��
	int GameState;
	int stage;
	int r_position;
	void GLViewSetup();
	int temp, temp1, temp2, temp3, temp4, temp5;
	double aa;	//���� ��������� ���� ��
	double phaiC;	//�Ӱ�
	double thetaC;	//���Ⱒ
	double distC;	//�ֽ������� ī�޶������ �Ÿ�	
	GLfloat ratio;	//��ü���� ���γ��̿� ������ ����
	double farZ;	//��ü���� �޸�
	double nearZ;	//��ü���� �ո�
	double fov;		//��ü���� �þ߰�
	double cnt[3];	//�ֽ���
	double view[3];	//����
	GLfloat m_ZScale;
	GLfloat m_YScale;
	GLfloat m_XScale;
	GLfloat m_zPos;
	GLfloat m_yPos;
	GLfloat m_xPos;
	UINT m_DrawType;
	GLfloat theta[3];
	GLfloat m_aLight;
	GLfloat m_AFinalLight;
	GLfloat m_SFinalLight;
	GLfloat m_DFinalLight;
	GLfloat m_sLight;
	GLfloat m_dLight;
	GLfloat m_xLP;
	GLfloat m_yLP;
	GLfloat m_zLP;
	GLubyte *m_bitmap;
	BITMAPFILEHEADER header;
	BITMAPINFO *info;

	BOOL m_bLight;
	void colorCube();
	void GLRenderScene();
	void GLResize(int cx, int cy);
	HDC m_hDC;
	HGLRC m_hRC;
	virtual ~CMfcglView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMfcglView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnButtonRota();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnButtonMove();
	afx_msg void OnButtonScale();
	afx_msg void OnButtonDolly();
	afx_msg void OnButtonDollyM();
	afx_msg void OnButtonDollyP();
	afx_msg void OnButtonPanP();
	afx_msg void OnButtonPanM();
	afx_msg void OnButtonTumbleP();
	afx_msg void OnButtonTumbleM();
	afx_msg void OnButtonTiltP();
	afx_msg void OnButtonTiltM();
	afx_msg void OnButtonHeightP();
	afx_msg void OnButtonHeightM();
	afx_msg void OnButtonZoomP();
	afx_msg void OnButtonZoomM();
	afx_msg void OnButtonTxp();
	afx_msg void OnButtonTxm();
	afx_msg void OnButtonTyp();
	afx_msg void OnButtonTym();
	afx_msg void OnButtonTzp();
	afx_msg void OnButtonTzm();
	afx_msg void OnButtonRxp();
	afx_msg void OnButtonRxm();
	afx_msg void OnButtonRyp();
	afx_msg void OnButtonRym();
	afx_msg void OnButtonRzp();
	afx_msg void OnButtonRzm();
	afx_msg void OnButtonSxp();
	afx_msg void OnButtonSxm();
	afx_msg void OnButtonSyp();
	afx_msg void OnButtonSym();
	afx_msg void OnButtonSzp();
	afx_msg void OnButtonSzm();
	afx_msg void OnButtonALP();
	afx_msg void OnButtonALM();
	afx_msg void OnButtonSLP();
	afx_msg void OnButtonSLM();
	afx_msg void OnButtonDLP();
	afx_msg void OnButtonDLM();
	afx_msg void OnButtonLPXP();
	afx_msg void OnButtonLPXM();
	afx_msg void OnButtonLPYP();
	afx_msg void OnButtonLPYM();
	afx_msg void OnButtonLPZP();
	afx_msg void OnButtonLPZM();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MfcglView.cpp
inline CMfcglDoc* CMfcglView::GetDocument()
   { return (CMfcglDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCGLVIEW_H__A3DD22F6_EDEE_471B_ADA2_74D2BCA0C178__INCLUDED_)
