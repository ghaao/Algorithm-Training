// MfcglView.cpp : implementation of the CMfcglView class
//

#include "stdafx.h"
#include "Mfcgl.h"

#include "MfcglDoc.h"
#include "MfcglView.h"
#include "MainFrm.h"

#include "ScaleDlg.h"
#include "math.h"
const double PI = 3.14159265;
#ifdef _DEBUG
#define new DEBUG_NEW
#define GROUND_LIMIT 50
#define GROUND_LIMITF 50.f
#define GAME_RUNNING     1    
#define GAME_END_WIN     2    // ���ӿ��� �̱� 
#define GAME_END_LOST    3    // ���ӿ��� �� 
#define GAME_EXIT        4    // ���� ����
#define GAME_START     5 
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfcglView

IMPLEMENT_DYNCREATE(CMfcglView, CView)

BEGIN_MESSAGE_MAP(CMfcglView, CView)
//{{AFX_MSG_MAP(CMfcglView)
ON_WM_SIZE()
ON_WM_CREATE()
ON_WM_DESTROY()
ON_COMMAND(ID_BUTTON_ROTA, OnButtonRota)
ON_WM_KEYDOWN()
ON_COMMAND(ID_BUTTON_MOVE, OnButtonMove)
ON_COMMAND(ID_BUTTON_SCALE, OnButtonScale)
ON_COMMAND(ID_BUTTON_DOLLY, OnButtonDolly)
ON_BN_CLICKED(IDC_BUTTON_DOLLYM, OnButtonDollyM)
ON_BN_CLICKED(IDC_BUTTON_DOLLYP, OnButtonDollyP)
ON_BN_CLICKED(IDC_BUTTON_PANP, OnButtonPanP)
ON_BN_CLICKED(IDC_BUTTON_PANM, OnButtonPanM)
ON_BN_CLICKED(IDC_BUTTON_TUMBLEP, OnButtonTumbleP)
ON_BN_CLICKED(IDC_BUTTON_TUMBLEM, OnButtonTumbleM)
ON_BN_CLICKED(IDC_BUTTON_TILTP, OnButtonTiltP)
ON_BN_CLICKED(IDC_BUTTON_TILTM, OnButtonTiltM)
ON_BN_CLICKED(IDC_BUTTON_HEIGHTP, OnButtonHeightP)
ON_BN_CLICKED(IDC_BUTTON_HEIGHTM, OnButtonHeightM)
ON_BN_CLICKED(IDC_BUTTON_ZOOMP, OnButtonZoomP)
ON_BN_CLICKED(IDC_BUTTON_ZOOMM, OnButtonZoomM)
ON_BN_CLICKED(IDC_BUTTON_TXP, OnButtonTxp)
ON_BN_CLICKED(IDC_BUTTON_TXM, OnButtonTxm)
ON_BN_CLICKED(IDC_BUTTON_TYP, OnButtonTyp)
ON_BN_CLICKED(IDC_BUTTON_TYM, OnButtonTym)
ON_BN_CLICKED(IDC_BUTTON_TZP, OnButtonTzp)
ON_BN_CLICKED(IDC_BUTTON_TZM, OnButtonTzm)
ON_BN_CLICKED(IDC_BUTTON_RXP, OnButtonRxp)
ON_BN_CLICKED(IDC_BUTTON_RXM, OnButtonRxm)
ON_BN_CLICKED(IDC_BUTTON_RYP, OnButtonRyp)
ON_BN_CLICKED(IDC_BUTTON_RYM, OnButtonRym)
ON_BN_CLICKED(IDC_BUTTON_RZP, OnButtonRzp)
ON_BN_CLICKED(IDC_BUTTON_RZM, OnButtonRzm)
ON_BN_CLICKED(IDC_BUTTON_SXP, OnButtonSxp)
ON_BN_CLICKED(IDC_BUTTON_SXM, OnButtonSxm)
ON_BN_CLICKED(IDC_BUTTON_SYP, OnButtonSyp)
ON_BN_CLICKED(IDC_BUTTON_SYM, OnButtonSym)
ON_BN_CLICKED(IDC_BUTTON_SZP, OnButtonSzp)
ON_BN_CLICKED(IDC_BUTTON_SZM, OnButtonSzm)
ON_BN_CLICKED(IDC_BUTTON_ALP, OnButtonALP)
ON_BN_CLICKED(IDC_BUTTON_ALM, OnButtonALM)
ON_BN_CLICKED(IDC_BUTTON_SLP, OnButtonSLP)
ON_BN_CLICKED(IDC_BUTTON_SLM, OnButtonSLM)
ON_BN_CLICKED(IDC_BUTTON_DLP, OnButtonDLP)
ON_BN_CLICKED(IDC_BUTTON_DLM, OnButtonDLM)
ON_BN_CLICKED(IDC_BUTTON_LPXP , OnButtonLPXP)
ON_BN_CLICKED(IDC_BUTTON_LPXM , OnButtonLPXM)
ON_BN_CLICKED(IDC_BUTTON_LPYP , OnButtonLPYP)
ON_BN_CLICKED(IDC_BUTTON_LPYM , OnButtonLPYM)
ON_BN_CLICKED(IDC_BUTTON_LPZP , OnButtonLPZP)
ON_BN_CLICKED(IDC_BUTTON_LPZM , OnButtonLPZM)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
// Standard printing commands
ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfcglView construction/destruction

CMfcglView::CMfcglView()
{
	// TODO: add construction code here
	m_DrawType = 0;
	theta[0] = 0;
	theta[1] = 0;
	theta[2] = 0;
	
	m_xPos = 0;
	m_yPos = 0;
	m_zPos = 0;
	
	m_XScale = 1;
	m_YScale = 1;
	m_ZScale = 1;
	
	//�ֽ���
	cnt[0] = 0; 
	cnt[1] = 0; 
	cnt[2] = 0;
	
	//����(ī�޶���ġ)
	view[0] = 100; 
	view[1] = 200;
	view[2] = 100;
	
	//ī�޶�
	distC = 100;
	thetaC= 90; phaiC = 25;
	
	//��ü��
	fov = 100; 
	ratio = 1.0;
	//nearZ = 0.2*distC;	farZ = distC+500;
	m_bLight = TRUE;
	
	m_aLight = 35.0f;
	m_sLight = 100.0f;
	m_dLight = 100.0f;
	
	m_xLP = 50.0f;
	m_yLP = 180.0f;
	m_zLP = 100.0f;

	//���� z ��

	z_B = -100;
	z_B1 = -100;
	z_B2 = -100;
	z_B3 = -100;
	z_B4 = -100;
	z_B5 = -100;


	//���� �ӵ��߰� ��
	speedadd = 0.;

	stage = 1;
	R_stage =1;

	r_position=0;

	//���� �� ����
	temp =0;
	temp1=0;
	temp2=0;
	temp3=0;
	temp4=0;
	temp5=0;

	//ĳ���� x,z ��
	x_C = 0.;
	z_C = -70.;

	aa=0;

	//�Ȱ� �ٸ��� ���� ������ ���� ���� ��
	leg_Base = 0;
	arm_Base = 0;
	head_Base =0;

	//�����̼� ����
	R_leg = 0;
	R_arm = 0;
	R_head =0;

	GameState = 5;
//	left_Arm =0;
//	right_Arm =0;

	B_Rotate =0;

	

}

CMfcglView::~CMfcglView()
{
}

BOOL CMfcglView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMfcglView drawing

void CMfcglView::OnDraw(CDC* pDC)
{
	CMfcglDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	wglMakeCurrent(m_hDC, m_hRC);
	
	GLRenderScene();
	CheckGameState();
	
	SwapBuffers(m_hDC);
	
	wglMakeCurrent(m_hDC, NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CMfcglView printing

BOOL CMfcglView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMfcglView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMfcglView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMfcglView diagnostics

#ifdef _DEBUG
void CMfcglView::AssertValid() const
{
	CView::AssertValid();
}

void CMfcglView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMfcglDoc* CMfcglView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMfcglDoc)));
	return (CMfcglDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMfcglView message handlers

void CMfcglView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	VERIFY(wglMakeCurrent(m_hDC, m_hRC));
	
	GLResize(cx, cy);
	
	VERIFY(wglMakeCurrent(NULL, NULL));	
}

void CMfcglView::GLResize(int cx, int cy)
{
	ratio =(float)cx/(float)cy;
	
	//view port ��ȯ
	glViewport(0, 0, cx, cy);
}

int CMfcglView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	/////
	int nPixelFormat;
	m_hDC = ::GetDC(m_hWnd);


	static PIXELFORMATDESCRIPTOR pfd = 
	{
		sizeof(PIXELFORMATDESCRIPTOR),
			1,
			PFD_DRAW_TO_WINDOW |
			PFD_SUPPORT_OPENGL |
			PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
			24,
			0,0,0,0,0,0,
			0,0,
			0,0,0,0,0,
			32,
			0,
			0,
			PFD_MAIN_PLANE,
			0,
			0,0,0
	};
	
	nPixelFormat = ChoosePixelFormat(m_hDC, &pfd);
	VERIFY(SetPixelFormat(m_hDC, nPixelFormat, &pfd));
	m_hRC = wglCreateContext(m_hDC);
	VERIFY(wglMakeCurrent(m_hDC, m_hRC));
	wglMakeCurrent(NULL, NULL);	
	return 0;
}

void CMfcglView::GLRenderScene()
{

	glLoadIdentity();
	
	GLViewSetup();	
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glFrontFace(GL_CCW);
    glEnable(GL_CULL_FACE);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);


	drawcenter();
	drawground();
	drawwall(-50);
	drawwall(50);
	
	glPushMatrix();

	drawCharacter(arm_Base, leg_Base, head_Base, 0);
	
	glPopMatrix();
	
	if(z_B>=100)
		z_B = -100;
	r_drawball(temp, z_B, 0,0);
	
	if(z_B1>=100)
		z_B1 = -100;
	r_drawball(temp1, z_B1, 0.2,0);

	if(z_B2>=100)
		z_B2 = -100;
	r_drawball(temp2, z_B2, 0.4,0);

	if(z_B3>=100)
		z_B3 = -100;
	r_drawball(temp3, z_B3, 0.6,0);

	if(z_B4>=100)
		z_B4 = -100;
	r_drawball(temp4, z_B4, 0.8,0);



	drawShadow();
	srand((double)time(NULL));
	
	if(z_B == -100 ){
		r_position = rand()%18;
		temp =r_position;
	}
	else if(z_B1==-100){
		r_position = rand()%18;
		temp1 =r_position;
	}
	else if(z_B2==-100){
		r_position = rand()%15;
		temp2 =r_position+3;
	}
	else if(z_B3==-100){
		r_position = rand()%16;
		temp3 = r_position+2;
	}
	else if(z_B4==-100){
		r_position = rand()%17;
		temp4 = r_position+1;
	}

	//////////////���� ĳ������ ��ǥ �浹 ���ǹ�/////////////////////
	if(z_B <= 74 &&z_B>=60){
		if(temp==0 || temp==1){
			if(x_C == 0)
				GameState = 3;
		}
		else if(temp==2 || temp==3 || temp==4){
			if(x_C == 20)
				GameState = 3;
		}
		else if( temp==5 || temp==6 || temp==7){
			if(x_C == -20 )
				GameState = 3;
		}
		else if(temp ==8 ||temp==9 || temp==10 ||temp==11){
			if(x_C == 0 || x_C ==20)
				GameState = 3;
		}
		else if(temp==12 ||temp==13||temp==14||temp==15){
			if(x_C == 0 || x_C == -20)
				GameState = 3;
		}
		else if(temp==16||temp==17){
			if(x_C == 20 || x_C ==-20)
				GameState = 3;
		}
	}
	if(z_B1 <= 74 &&z_B1>=60){
		if(temp1==0 || temp1==1){
			if(x_C == 0)
				GameState = 3;
		}
		else if(temp1==2 || temp1==3 || temp1==4){
			if(x_C == 20)
				GameState = 3;
		}
		else if( temp1==5 || temp1==6 || temp1==7){
			if(x_C == -20 )
				GameState = 3;
		}
		else if(temp1 ==8 ||temp1==9 || temp1==10 ||temp1==11){
			if(x_C == 0 || x_C ==20)
				GameState = 3;
		}
		else if( temp1==12||temp1==13||temp1==14||temp1==15){
			if(x_C == 0 || x_C == -20)
				GameState = 3;
		}
		else if(temp1==16||temp1==17){
			if(x_C == 20 || x_C ==-20)
				GameState = 3;
		}
	}
	if(z_B2 <= 74 &&z_B2>=60){
		if(temp2==0 || temp2==1){
			if(x_C == 0)
				GameState = 3;
		}
		else if(temp2==2 || temp2==3 || temp2==4){
			if(x_C == 20)
				GameState = 3;
		}
		else if( temp2==5 || temp2==6 || temp2==7){
			if(x_C == -20 )
				GameState = 3;
		}
		else if(temp2 ==8 ||temp2==9 || temp2==10 ||temp2==11){
			if(x_C == 0 || x_C ==20)
				GameState = 3;
		}
		else if( temp2==12 || temp2==13||temp2==14||temp2==15){
			if(x_C == 0 || x_C == -20)
				GameState = 3;
		}
		else if(temp2==16||temp2==17){
			if(x_C == 20 || x_C ==-20)
				GameState = 3;
		}
	}
	if(z_B3 <= 74 &&z_B3>=60){
		if(temp3==0 || temp3==1){
			if(x_C == 0)
				GameState = 3;
		}
		else if(temp3==2 || temp3==3 || temp3==4){
			if(x_C == 20)
				GameState = 3;
		}
		else if( temp3==5 || temp3==6 || temp3==7){
			if(x_C == -20 )
				GameState = 3;
		}
		else if(temp3 ==8 ||temp3==9 || temp3==10 ||temp3==11){
			if(x_C == 0 || x_C ==20)
				GameState = 3;
		}
		else if(temp3==12 || temp3==13||temp3==14||temp3==15){
			if(x_C == 0 || x_C == -20)
				GameState = 3;
		}
		else if(temp3==16||temp3==17){
			if(x_C == 20 || x_C ==-20)
				GameState = 3;
		}
	}
	if(z_B4 <= 74 &&z_B4>=60){
		if(temp4==0 || temp4==1){
			if(x_C == 0)
				GameState = 3;
		}
		else if(temp4==2 || temp4==3 || temp4==4){
			if(x_C == 20)
				GameState = 3;
		}
		else if( temp4==5 || temp4==6 || temp4==7){
			if(x_C == -20 )
				GameState = 3;
		}
		else if(temp4 ==8 ||temp4==9 || temp4==10 ||temp4==11){
			if(x_C == 0 || x_C ==20)
				GameState = 3;
		}
		else if(temp4==12 || temp4==13||temp4==14||temp4==15){
			if(x_C == 0 || x_C == -20)
				GameState = 3;
		}
		else if(temp4==16||temp4==17){
			if(x_C == 20 || x_C ==-20)
				GameState = 3;
		}
	}
	Light();
	glFlush();	
}

void CMfcglView::OnDestroy() 
{
	wglDeleteContext(m_hRC);
	::ReleaseDC(m_hWnd, m_hDC);
	
	CView::OnDestroy();	
	// TODO: Add your message handler code here
	
}

void CMfcglView::colorCube()
{
	GLfloat MyVertices[8][3] = {{-0.25, -0.25, 0.25}, {-0.25, 0.25, 0.25}, {0.25, 0.25, 0.25}, {0.25, -0.25, 0.25},
	{-0.25, -0.25, -0.25}, {-0.25, 0.25, -0.25}, {0.25, 0.25, -0.25}, {0.25, -0.25, -0.25}};
	GLfloat MyColors[8][3] = {{0.2, 0.2, 0.2}, {1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0},
	{1.0, 0.0, 1.0}, {1.0, 1.0, 1.0}, {1.0, 1.0, 1.0}};
	GLubyte MyVertexList[24]={0,3,2,1, 2,3,7,6, 0,4,7,3, 1,2,6,5, 4,5,6,7, 0,1,5,4};
	
    glFrontFace(GL_CCW);							
    glEnable(GL_CULL_FACE);						
    glEnableClientState(GL_COLOR_ARRAY);							
    glEnableClientState(GL_VERTEX_ARRAY);
    glColorPointer(3, GL_FLOAT, 0, MyColors);				
    glVertexPointer(3, GL_FLOAT, 0, MyVertices);
	for(GLint i=0; i<6; i++)
		glDrawElements(GL_POLYGON, 4, GL_UNSIGNED_BYTE, &MyVertexList[4*i]);
	
	glColor3f(0.0f,0.0f,0.0f);
	glutWireCube(0.5);
}

void CMfcglView::OnButtonRota() 
{
	// TODO: Add your command handler code here
	m_DrawType = 2;
}

void CMfcglView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
	switch (nChar)
	{
	case VK_UP:         
		if(m_DrawType==1)
			m_yPos += 1;
		if(m_DrawType==2) 
			theta[0] += 1.0f; 
		if(m_DrawType==4)	//Dolly
			distC = distC - 10;	//�����̰���.
		SetTimer(101,1,NULL);
		break;              
	case VK_DOWN:      
		if(m_DrawType==1)
			m_yPos -= 1;
		if(m_DrawType==2) 
			theta[0] -= 1.0f; 
		if(m_DrawType==4)	//Dolly
			distC = distC + 10;	//�ָ�����.
		break;      
	case VK_LEFT:
		if(m_DrawType==1)
			m_xPos -= 1;
		if(m_DrawType==4)	//zoom in
			fov = fov - 5;
		x_C-=20;
		if(x_C <= -20)
			x_C=-20;
		
		
		break;
	case VK_RIGHT:
		if(m_DrawType==1)
			m_xPos += 1;
		if(m_DrawType==4)	//zoom out
			fov = fov + 5;
		x_C+=20;
		if(x_C >= 20)
			x_C=20;
				
		break;		
    }
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonMove() 
{
	// TODO: Add your command handler code here
	m_DrawType = 1;
}

void CMfcglView::drawcenter()
{	
	glPushMatrix();
	glTranslatef(0, -5., 0);
	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex3f(50,0,-100);
	glVertex3f(50,0,100);
	glEnd();
	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex3f(-50,0,-100);
	glVertex3f(-50,0,100);
	glEnd();
	glPopMatrix();
}

void CMfcglView::OnButtonScale() 
{
	// TODO: Add your command handler code here
	CScaleDlg dlg;
	if(dlg.DoModal() == IDOK)
	{
		if(dlg.x_Scale > 0) m_XScale = dlg.x_Scale;
		if(dlg.y_Scale > 0) m_YScale = dlg.y_Scale;
		if(dlg.z_Scale > 0) m_ZScale = dlg.z_Scale;
		InvalidateRect(NULL,FALSE);
	}
	
}

void CMfcglView::OnButtonDolly() 
{
	// TODO: Add your command handler code here
	m_DrawType = 4;
}

void CMfcglView::GLViewSetup()
{
	// Reset coordinate system
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	nearZ = 0.2*distC;
	farZ = distC-200;
	
	gluPerspective(fov,(double)ratio, nearZ,farZ);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	view[0] = cnt[0] + distC * cos(PI * thetaC/180) * cos(PI * phaiC/180);
	view[1] = cnt[1] + distC * sin(PI * phaiC/180);
	view[2] = cnt[2] + distC * sin(PI * thetaC/180) * cos(PI * phaiC/180);
	//������ �����ڼ�
	gluLookAt(view[0],view[1],view[2],cnt[0],cnt[1],cnt[2],0,1,0);
	
	GLfloat lightPos[]={m_xLP,m_yLP,m_zLP,1.0f};
	glLightfv(GL_LIGHT0, GL_POSITION,lightPos);
}

void CMfcglView::OnButtonDollyP() 
{
	// TODO: Add your control notification handler code here
	distC = distC - 10;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonDollyM() 
{
	// TODO: Add your control notification handler code here
	distC = distC + 10;	//�ָ�����.
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonZoomP() 
{
	// TODO: Add your control notification handler code here
	fov = fov - 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonZoomM() 
{
	// TODO: Add your control notification handler code here
	fov = fov + 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonPanP() 
{
	// TODO: Add your control notification handler code here
	thetaC = thetaC + 5; 
	//�ֽ����� ����
	cnt[0]= view[0] - distC*cos(PI*thetaC/180)*cos(PI*phaiC/180);
	cnt[1]= view[1] - distC*sin(PI * phaiC/180);
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonPanM() 
{
	// TODO: Add your control notification handler code here
	thetaC = thetaC - 5; 
	//�ֽ����� ����
	cnt[0]= view[0] - distC*cos(PI*thetaC/180)*cos(PI*phaiC/180);
	cnt[1]= view[1] - distC*sin(PI * phaiC/180);
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTumbleP() 
{
	// TODO: Add your control notification handler code here
	thetaC = thetaC + 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTumbleM() 
{
	// TODO: Add your control notification handler code here
	thetaC = thetaC - 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTiltP() 
{
	// TODO: Add your control notification handler code here
	phaiC= phaiC + 5;
	//�ֽ����� ����
	cnt[0]= view[0] - distC*cos(PI*thetaC/180)*cos(PI*phaiC/180);
	cnt[1]= view[1] - distC*sin(PI*phaiC/180);
	cnt[2]= view[2] - distC*sin(PI*thetaC/180)*cos(PI*phaiC/180);
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTiltM() 
{
	// TODO: Add your control notification handler code here
	phaiC= phaiC - 5;
	//�ֽ����� ����
	cnt[0]= view[0] - distC*cos(PI*thetaC/180)*cos(PI*phaiC/180);
	cnt[1]= view[1] - distC*sin(PI*phaiC/180);
	cnt[2]= view[2] - distC*sin(PI*thetaC/180)*cos(PI*phaiC/180);
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonHeightP() 
{
	// TODO: Add your control notification handler code here
	phaiC= phaiC + 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonHeightM() 
{
	// TODO: Add your control notification handler code here
	phaiC= phaiC - 5;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTxp() 
{
	// TODO: Add your control notification handler code here
	m_xPos += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTxm() 
{
	// TODO: Add your control notification handler code here
	m_xPos -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTyp() 
{
	// TODO: Add your control notification handler code here
	m_yPos += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTym() 
{
	// TODO: Add your control notification handler code here
	m_yPos -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTzp() 
{
	// TODO: Add your control notification handler code here
	m_zPos += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonTzm() 
{
	// TODO: Add your control notification handler code here
	m_zPos -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRxp() 
{
	// TODO: Add your control notification handler code here
	theta[0] += 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRxm() 
{
	// TODO: Add your control notification handler code here
	theta[0] -= 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRyp() 
{
	// TODO: Add your control notification handler code here
	theta[1] += 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRym() 
{
	// TODO: Add your control notification handler code here
	theta[1] -= 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRzp() 
{
	// TODO: Add your control notification handler code here
	theta[2] += 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonRzm() 
{
	// TODO: Add your control notification handler code here
	theta[2] -= 1.0f; 
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSxp() 
{
	// TODO: Add your control notification handler code here
	m_XScale += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSxm() 
{
	// TODO: Add your control notification handler code here
	m_XScale -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSyp() 
{
	// TODO: Add your control notification handler code here
	m_YScale += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSym() 
{
	// TODO: Add your control notification handler code here
	m_YScale -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSzp() 
{
	// TODO: Add your control notification handler code here
	m_ZScale += 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonSzm() 
{
	// TODO: Add your control notification handler code here
	m_ZScale -= 1;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::OnButtonALP()
{
	m_aLight += 5;
	
	if(m_aLight < 0)
		m_aLight = 0;
	else if(m_aLight > 100)
		m_aLight = 100;
	LingtR();
}

void CMfcglView::OnButtonALM()
{
	m_aLight -= 5;
	
	if(m_aLight < 0)
		m_aLight = 0;
	else if(m_aLight > 100)
		m_aLight = 100;
	LingtR();
}

void CMfcglView::OnButtonDLP()
{
	m_dLight += 5;
	
	if(m_dLight < 0)
		m_dLight = 0;
	else if(m_dLight > 100)
		m_dLight = 100;
	LingtR();
}
void CMfcglView::OnButtonDLM()
{
	m_dLight -= 5;
	
	if(m_dLight < 0)
		m_dLight = 0;
	else if(m_dLight > 100)
		m_dLight = 100;
	
	LingtR();
}
void CMfcglView::OnButtonSLP()
{
	m_sLight += 5;
	
	if(m_sLight < 0)
		m_sLight = 0;
	else if(m_sLight > 100)
		m_sLight = 100;
	LingtR();
}
void CMfcglView::OnButtonSLM()
{
	m_sLight -= 5;
	
	if(m_sLight < 0)
		m_sLight = 0;
	else if(m_sLight > 100)
		m_sLight = 100;
	LingtR();
}
void CMfcglView::OnButtonLPXP()
{
	m_xLP += 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}	
void CMfcglView::OnButtonLPXM()
{
	m_xLP -= 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}
void CMfcglView::OnButtonLPYP()
{
	m_yLP += 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}
void CMfcglView::OnButtonLPYM()
{
	m_yLP -= 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}
void CMfcglView::OnButtonLPZP()
{
	m_zLP += 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}
void CMfcglView::OnButtonLPZM()
{
	m_zLP -= 5;
	m_bLight = TRUE;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::myglWireCube()
{
	//��, ����1�� �Թ�ü(�Թ�ü�� �߽��� ����)
	static float p[8][3]={{0.5f,0.5f,0.5f},{-0.5f,0.5f,0.5f},{-0.5f,-0.5f,0.5f},
	{0.5f,-0.5f,0.5f},{0.5f,0.5f,-0.5f},{-0.5f,0.5f,-0.5f},{-0.5f,-0.5f,0-0.5f},
	{0.5f,-0.5f,-0.5f}};
	
	glBegin(GL_QUADS);
	//z����
	glNormal3f(0.0f, 0.0f, 1.0f);
	glVertex3fv(p[0]); glVertex3fv(p[1]);
	glVertex3fv(p[2]); glVertex3fv(p[3]);
	//x����
	glNormal3f(1.0f, 0.0f, 0.0f);
	glVertex3fv(p[0]); glVertex3fv(p[3]);
	glVertex3fv(p[7]); glVertex3fv(p[4]);
	//y����
	glNormal3f(0.0f, 1.0f, 0.0f);
	glVertex3fv(p[0]); glVertex3fv(p[4]);
	glVertex3fv(p[5]); glVertex3fv(p[1]);
	//-x����
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glVertex3fv(p[1]); glVertex3fv(p[5]);
	glVertex3fv(p[6]); glVertex3fv(p[2]);
	//-y����
	glNormal3f(0.0f, -1.0f, 0.0f);
	glVertex3fv(p[2]); glVertex3fv(p[6]);
	glVertex3fv(p[7]); glVertex3fv(p[3]);
	//-z����
	glNormal3f(0.0f, 0.0f, -1.0f);
	glVertex3fv(p[4]); glVertex3fv(p[7]);
	glVertex3fv(p[6]); glVertex3fv(p[5]);
	glEnd();
}

void CMfcglView::LingtR()
{
	if(m_aLight>= 0)
		m_AFinalLight = m_aLight/100.0f;
	if(m_dLight>= 0)
		m_DFinalLight = m_dLight/100.0f;
	if(m_sLight>= 0)
		m_SFinalLight = m_sLight/100.0f;
	m_bLight=true;
	InvalidateRect(NULL,FALSE);
}

void CMfcglView::Light()
{
	GLfloat ambientLight[] = {m_AFinalLight,m_AFinalLight,m_AFinalLight, 1.0f };
	GLfloat diffuseLight[]={m_DFinalLight,m_DFinalLight,m_DFinalLight,1.0f};// ���ݻ籤����
	GLfloat specular[]={m_SFinalLight,m_SFinalLight,m_SFinalLight,1.0f};//���ݻ籤����
	GLfloat specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };// ���ݻ���
	
	CMainFrame *pFrame = (CMainFrame *)AfxGetMainWnd();
	
	if(!m_bLight)
	{
		glEnable(GL_LIGHTING);
	}
	else
	{
		glEnable(GL_LIGHTING);
		glLightfv(GL_LIGHT0,GL_AMBIENT,ambientLight);//�ֺ���
		glLightfv(GL_LIGHT0,GL_DIFFUSE, diffuseLight); //���ݻ籤
		glLightfv(GL_LIGHT0,GL_SPECULAR, specular);//���ݻ籤
		glEnable(GL_LIGHT0); // GL_LIGHT0 ��������밡���ϰ��Ѵ�.
		glEnable(GL_COLOR_MATERIAL);
		glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
		glMaterialfv(GL_FRONT, GL_SPECULAR,specref);//�ո������ݻ�
		glMateriali(GL_FRONT,GL_SHININESS,64);// ���ݻ����̶���Ʈ������
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_NORMALIZE);
	}
	CTime timer = CTime::GetCurrentTime();
	CString realtime = timer.Format(_T("%Y/%m/%d %H:%M:%S"));
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_AL , m_aLight);
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_SL , m_sLight);
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_DL , m_dLight);
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT1 , R_stage);
	pFrame->m_wndDialogBar.SetDlgItemText(IDC_EDIT2 , realtime);	
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_LPX , m_xLP);
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_LPY , m_yLP);
	pFrame->m_wndDialogBar.SetDlgItemInt(IDC_EDIT_LPZ , m_zLP);
}

void CMfcglView::ReduceToUnit(float vector[3])
{
	float length;
	
	//������ ���̸� ����Ѵ�.
	length = (float)sqrt((vector[0]*vector[0]) + 
		(vector[1]*vector[1]) +
		(vector[2]*vector[2]));
	// ���̰� 0�� ����� ���Ϳ��� ������ ���� �״��Ͽ� ���α׷��� �������� �ʵ��� �Ѵ�.
	if(length == 0.0f) length = 1.0f;
	
	// �� ������ ������ ���̷� ������ ���� ���Ͱ� �ȴ�.
	vector[0] /= length;
	vector[1] /= length;
	vector[2] /= length;	
}

void CMfcglView::calcNomal(float v[3][3], float out[3])
{
	float v1[3], v2[3];
	static const int x = 0;
	static const int y = 1;
	static const int z = 2;
	
	// �� ������ ���� 2���� ���͸� ���Ѵ�.
	v1[x] = v[1][x] - v[0][x];
	v1[y] = v[1][y] - v[0][y];
	v1[z] = v[1][z] - v[0][z];
	
	v2[x] = v[2][x] - v[0][x];
	v2[y] = v[2][y] - v[0][y];
	v2[z] = v[2][z] - v[0][z];		
	
	// ���� ���͸� ���ϱ� ���� �� ������ ������ ���Ѵ�.
	// ����� out[]�� ����ȴ�.
	out[x] = v1[y]*v2[z] - v1[z]*v2[y];
	out[y] = v1[z]*v2[x] - v1[x]*v2[z];
	out[z] = v1[x]*v2[y] - v1[y]*v2[x];
	
	// ���͸� ����ȭ�Ѵ�(���̸� 1�� ���δ�)
	ReduceToUnit(out);
}

void CMfcglView::drawShadow()//�׸��� �׸���
{
	static float shadowDiffuse[4] = {0.2f,0.2f,0.2f,0.3f};
	static float shadowSpecular[4] ={0.0f,0.0f,0.0f,1.0f};
	double mat[16]; //��ȯ ��Ʈ����
	float xyz[3];
	glPushMatrix();
	glMatrixMode(GL_MODELVIEW);
	glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,shadowDiffuse);
	glMaterialfv(GL_FRONT,GL_SPECULAR,shadowSpecular);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDepthMask(GL_FALSE);

	xyz[0]=m_xPos; xyz[1]=m_yPos; xyz[2]=m_zPos;
	CalcShadowMat(xyz,mat);
	glMultMatrixd(mat);

	
	glPushMatrix();
		if(z_B>=100)
			z_B = -100;
			glColor3f(0.2, 0.2, 0.2);
		r_drawball(temp, z_B, 0,1);

		if(z_B1>=100)
			z_B1 = -100;
			glColor3f(0.2, 0.2, 0.2);
		r_drawball(temp1, z_B1, 0.2,1);

		if(z_B2>=100)
			z_B2 = -100;
			glColor3f(0.2, 0.2, 0.2);
		r_drawball(temp2, z_B2, 0.4,1);

		if(z_B3>=100)
			z_B3 = -100;
			glColor3f(0.2, 0.2, 0.2);
		r_drawball(temp3, z_B3, 0.6,1);

		if(z_B4>=100)
			z_B4 = -100;
			glColor3f(0.2, 0.2, 0.2);
		r_drawball(temp4, z_B4, 0.8,1);
	glPopMatrix();

	drawCharacter(arm_Base, leg_Base, head_Base, 1);
	
	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);
	glPopMatrix();
	}

void CMfcglView::CalcShadowMat(float *xyz, double *mat)
{
	double cx,cy,cz;//
	double a,b,c,d ;// ���� ���
	double s;
	double x,y,z;
	float lightPos[4];
	lightPos[0] = m_xLP;// ������ ��ġ
	lightPos[1] = m_yLP;
	lightPos[2] = m_zLP;
	x = (double)(lightPos[0]-xyz[0]);
	y = (double)(lightPos[1]-xyz[1]);
	z = (double)(lightPos[2]-xyz[2]);
	s = sqrt(x*x+y*y+z*z);
	cx = x/s;
	cy = y/s;
	cz = z/s;

	a = 0.0f;
	b = 1.0f;
	c = 0.0f;
	d = 5.0f;
	//shadow matrix//����� ������
	
	mat[0] = b*cy+c*cz; mat[1] = -a*cy;
	mat[2] = -a*cz; mat[3] = 0.0f;
	mat[4] = -b*cx; mat[5] = a*cx+c*cz;
	mat[6] = -b*cz; mat[7] = 0.0f;
	mat[8] = -c*cx; mat[9] = -c*cy;
	mat[10] = a*cx+b*cy; mat[11] = 0.0f;
	mat[12] = -d*cx; mat[13] = -d*cy;
	mat[14] = -d*cz; mat[15] = a*cx+b*cy+c*cz;
}


void CMfcglView::OnTimer(UINT nIDEvent) //�ð��� ������ ���� �����̴� �ҽ�
{
	// TODO: Add your message handler code here and/or call default
 


	stage+=1;
	B_Rotate+=10; //���� ȸ��
	if(B_Rotate==360)
		B_Rotate=0;

	if(z_C < 70)
		z_C+= 4;

	if(aa<=3)
		aa+=0.01;
	else
		aa=2.8;
	//���� ������
		z_B+=2+speedadd;

		if(aa >= 0.2){
			z_B1+=2+speedadd;
		}
		if(aa >= 0.4){
			z_B2+=2+speedadd;
		}
		if(aa >= 0.6){
			z_B3+=2+speedadd;
		}
		if(aa >= 0.8){
			z_B4+=2+speedadd;
		}

		if(stage == 500){
		speedadd+= 0.5; //���� ���ӵ�
		R_stage+=1;
		stage = 0;
	}
	if(R_stage == 6)//������ 6�� �Ǹ� ���� ����
		GameState = 2;

	//ĳ������ ������
	if(R_arm == 0){
		arm_Base+=20+speedadd;
	}
	if(R_arm ==1){
		arm_Base-=20+speedadd;
	}
	if(arm_Base >= 45)
		R_arm = 1;
	else if(arm_Base < -45)
		R_arm = 0;

	if(R_leg == 0){
		leg_Base+=20+speedadd;
	}
	if(R_leg ==1){
		leg_Base-=20+speedadd;
	}
	if(leg_Base >= 85)
		R_leg = 1;
	else if(leg_Base < -85)
		R_leg = 0;

	if(R_head == 0){
		head_Base+=15+speedadd;
	}
	if(R_head ==1){
		head_Base-=15+speedadd;
	}
	if(head_Base >= 20)
		R_head = 1;
	else if(head_Base < -20)
		R_head = 0;

	Invalidate(FALSE);
	CView::OnTimer(nIDEvent);
}


void CMfcglView::drawCharacter(double arm_Base1, double leg_Base1, double head_Base1, int ShadowCheck)//ĳ���� �׸���
{
		if(ShadowCheck == 0){
		glTranslatef(x_C, 2.5, z_C);
		glRotatef(head_Base1,0,1,0);
		glScalef(m_XScale,m_YScale,m_ZScale);
		glTranslatef(m_xPos, m_yPos, m_zPos);

		glPushMatrix();
		glTranslatef(0, 5, 0);
		glRotatef(arm_Base1,1,0,0);
		glTranslatef(0, -5, 0);
		rightarm(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glTranslatef(0, 5, 0);
		glRotatef((-1*arm_Base1),1,0,0);
		glTranslatef(0, -5, 0);
		leftarm(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glRotatef(leg_Base1,1,0,0);
		rightleg(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glRotatef((-1*leg_Base1),1,0,0);
		leftleg(ShadowCheck);
		glPopMatrix();

		body(ShadowCheck);
		glColor3f(1,1,0);
		head(ShadowCheck);
		face_eye();
		face_mouth();
		}
		
		else if(ShadowCheck == 1){
		glTranslatef(x_C, 2.5, z_C);
		glRotatef(head_Base1,0,1,0);
		glScalef(m_XScale,m_YScale,m_ZScale);
		glTranslatef(m_xPos, m_yPos, m_zPos);

		glPushMatrix();
		glTranslatef(0, 5, 0);
		glRotatef(arm_Base1,1,0,0);
		glTranslatef(0, -5, 0);
		rightarm(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glTranslatef(0, 5, 0);
		glRotatef((-1*arm_Base1),1,0,0);
		glTranslatef(0, -5, 0);
		leftarm(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glRotatef(leg_Base1,1,0,0);
		rightleg(ShadowCheck);
		glPopMatrix();

		glPushMatrix();
		glRotatef((-1*leg_Base1),1,0,0);
		leftleg(ShadowCheck);
		glPopMatrix();

		body(ShadowCheck);
		glColor3f(1,1,0);
		head(ShadowCheck);
		}
			
}

void CMfcglView::drawball(double x_B, double z_B, int n)// ���׸���
{
if(n==0){
	glPushMatrix();
		glColor3f(0.0f,0.0f,0.0f);
		glTranslatef(x_B, 5., z_B);
		glRotatef(B_Rotate,1,0,0);
		glutSolidSphere(10.0, 20, 16);
}
else{
	glPushMatrix();
		glColor3f(0.0f,0.0f,0.0f);
		glTranslatef(x_B, 5., z_B);
		glRotatef(B_Rotate,1,0,0);
		glutSolidSphere(10.0, 20, 16);

	
}		
glPopMatrix();
}
	

void CMfcglView::r_drawball(int temp, double z, double time, int n)
{	
	if(aa>=time){
		if(temp==0||temp==1){
			drawball(0.0, z,n);
		}
		else if(temp==2 || temp==3 || temp==4){
			drawball(20.0, z,n);
		}
		else if( temp==5 || temp==6 || temp==7){
			drawball(-20.0, z,n);
		}
		else if(temp ==8 ||temp==9 || temp==10 ||temp==11 ){
			drawball(0.0, z,n);
			drawball(20.0, z,n);
		}
		else if(temp==12 ||temp==13||temp==14||temp==15){
	
			drawball(0.0, z,n);
			drawball(-20.0, z,n);	
		}
		else if(temp==16||temp==17){
			drawball(20.0, z,n);
			drawball(-20.0, z,n);
			
		}
	
	}

}

void CMfcglView::drawground()
{
	float widG,widFloorX,widFloorZ,x0,x1,z0,z1;
	short i,j,nx,nz;
	int a;
	
	widFloorX = 100.0f;
	widFloorZ = 2000.0f;
	widG = 12.5f;
	nx = (short)(widFloorX/widG);
	nz = (short)(widFloorZ/widG);
	glPushAttrib(GL_CURRENT_BIT);
	
	glColor3f(0.2f,0.2f,0.2f);

    for(j=0;j<nz;j++) {
		for(i=0;i<nx;i++) {
			a = (double)(i+j); 
			if(fmod(a,2.0) == 0.0) 
			 glColor4f(0.5f,0.6f,0.7f,1.0f);
			else 
			 glColor4f(.2f,0.4f,0.3f,1.0f);
				
			glPushMatrix(); 
			  x0 = -widFloorX/2.0f+(float)i*widG+widG/2.0f; 
		      z0 = -widFloorZ/2.0f+(float)j*widG+widG/2.0f; 
		  	  glTranslatef(x0, -5.0f, z0); 
			  glBegin(GL_QUADS); 
				glNormal3f(0.0f,1.0f,0.0f); //z���� 
				glVertex3f(widG/2.0f, -0.1f, -widG/2.0f); 
				glVertex3f(-widG/2.0f, -0.1f, -widG/2.0f); 
				glVertex3f(-widG/2.0f, -0.1f, widG/2.0f); 
				glVertex3f(widG/2.0f, -0.1f, widG/2.0f); 
			  glEnd(); 
			  glPopMatrix(); 
		}
	}	


	glPopAttrib();
}

void CMfcglView::drawwall(int x)
{
	float widG,widFloorY,widFloorZ,y0,y1,z0,z1;
	short i,j,ny,nz;
	int a;
	
	widFloorY = 200.0f;
	widFloorZ = 2000.0f;
	widG = 12.5f;
	ny = (short)(widFloorY/widG);
	nz = (short)(widFloorZ/widG);
	glPushAttrib(GL_CURRENT_BIT);
	
	glColor3f(0.4f,0.1f,0.5f);

    for(j=0;j<nz;j++) {
		for(i=0;i<ny;i++) {
			a = (double)(i+j); 
			if(fmod(a,2.0) == 0.0) 
			 glColor4f(0.5f,0.6f,0.7f,1.0f);
			else 
			 glColor4f(.2f,0.4f,0.3f,1.0f);
			
			glPushMatrix(); 
			  y0 = -widFloorY/2.0f+(float)i*widG+widG/2.0f; 
		      z0 = -widFloorZ/2.0f+(float)j*widG+widG/2.0f; 
		  	  glTranslatef(x, y0, z0);
			  glTranslatef(0, 45, 0);
			  glBegin(GL_QUADS);
			  if(x>=0){	
				glNormal3f(1.0f,.0f,0.0f); //z���� 
				glVertex3f(-0.1f, widG/2.0f, -widG/2.0f); 
				glVertex3f(-0.1f, -widG/2.0f, -widG/2.0f); 
				glVertex3f( -0.1f, -widG/2.0f, widG/2.0f); 
				glVertex3f(-0.1f, widG/2.0f, widG/2.0f); 
			  }
			  else if(x<0){	
				glNormal3f(1.0f,.0f,0.0f); //z���� 
				glVertex3f(-0.1f, -widG/2.0f, widG/2.0f); 
				glVertex3f(-0.1f, -widG/2.0f, -widG/2.0f); 
				glVertex3f( -0.1f, widG/2.0f, -widG/2.0f); 
				glVertex3f(-0.1f, widG/2.0f, widG/2.0f); 

			  }

			  glEnd(); 
			  glPopMatrix(); 
			
		}
	}	
	glPopAttrib();

}


GLubyte* CMfcglView::read_texturemapping_img(const char *filename, BITMAPINFO **info)
{
	FILE *fp;
	GLubyte *bits;
	int bitsize, infosize;
	if((fp = fopen(filename, "rb")) == NULL)
		return NULL;
	if(fread(&header, sizeof(BITMAPFILEHEADER), 1, fp) < 1){
		fclose(fp);
		return NULL;
	}
	if(header.bfType != 'MB'){
		fclose(fp);
		return NULL;
	}
	
	infosize = header.bfOffBits -sizeof(BITMAPFILEHEADER);
	
	if((*info = (BITMAPINFO *)malloc(infosize)) == NULL)
	{
		fclose(fp);
		return NULL;
	}
	if(fread(*info, 1, infosize, fp) < (unsigned int)infosize)
	{
		free(*info);
		fclose(fp);
		return NULL;
	}
	if((bitsize = (*info)->bmiHeader.biSizeImage) == 0)
	{
		bitsize = ((*info)->bmiHeader.biWidth * (*info)->bmiHeader.biBitCount + 7) / 8 * abs((*info)->bmiHeader.biHeight);
	}
	if((bits = (unsigned char *)malloc(bitsize)) == NULL)
	{
		free(*info);
		fclose(fp);
		return NULL;
	}
	if(fread(bits, 1, bitsize, fp) < (unsigned int) bitsize) 
	{
		free(*info);
		free(bits);
		fclose(fp);
		return NULL;
	}
	fclose(fp);
	return bits;
}


void CMfcglView::rightarm(int ShadowCheck) //������ ��
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glColor3f(0.4,0.3,1);
//	glRotatef((-1*arm_Base), 0, 0, 1);
	glTranslatef(-5, 2.5, 0);
	glRotatef(-30, 0, 0, 1);
	glScalef(0.1,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(-6.25, 0, -0.5);
	glRotatef(-90, -90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();
	}
	else if(ShadowCheck == 1){
	glPushMatrix();
	glColor3f(0,0,0);
//	glRotatef((-1*arm_Base), 0, 0, 1);
	glTranslatef(-5, 2.5, 0);
	glRotatef(-30, 0, 0, 1);
	glScalef(0.1,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(-6.25, 0, -0.5);
	glRotatef(-90, -90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();
	}
	
	
}

void CMfcglView::leftarm(int ShadowCheck)// ������
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(5, 2.5, 0);
	glRotatef(30, 0, 0, 1);
	glScalef(0.1,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(6.25, 0, -0.5);
	glRotatef(-90, -90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();
	}
	else if(ShadowCheck == 1){
		glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(5, 2.5, 0);
	glRotatef(30, 0, 0, 1);
	glScalef(0.1,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(6.25, 0, -0.5);
	glRotatef(-90, -90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();
	}

}

void CMfcglView::rightleg(int ShadowCheck)//������ �ٸ�
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glColor3f(0.4,0.3,1);
//	glRotatef(leg_Base, 0, 0, 1);
	glTranslatef(-3, -2.5, 0);
	glRotatef(-20, 0, 0, 1);
	glScalef(0.2,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(-4.01, -4.7, 0.5);
	glRotatef(-90, 90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(-4.21, -5.7, -4.0);
	glScalef(0.6,1,0.5);
	glutSolidSphere(2.0, 20, 16);
	glPopMatrix();
	}
	else if (ShadowCheck == 1){
		glPushMatrix();
	glColor3f(0,0,0);
//	glRotatef(leg_Base, 0, 0, 1);
	glTranslatef(-3, -2.5, 0);
	glRotatef(-20, 0, 0, 1);
	glScalef(0.2,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(-4.01, -4.7, 0.5);
	glRotatef(-90, 90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(-4.21, -5.7, -4.0);
	glScalef(0.6,1,0.5);
	glutSolidSphere(2.0, 20, 16);
	glPopMatrix();
	}
}

void CMfcglView::leftleg(int ShadowCheck)//���� �ٸ�
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(3, -2.5, 0);
	glRotatef(20, 0, 0, 1);
	glScalef(0.2,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(4.21, -4.7, 0.5);
	glRotatef(-90, 90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4,0.3,1);
	glTranslatef(4.01, -5.7, -4.0);
	glScalef(0.6,1,0.5);
	glutSolidSphere(2.0, 20, 16);
	glPopMatrix();
	}
	else if(ShadowCheck == 1){
	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(3, -2.5, 0);
	glRotatef(20, 0, 0, 1);
	glScalef(0.2,0.5,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(4.21, -4.7, 0.5);
	glRotatef(-90, 90, 0, 1);
	glTranslatef(0, 2.5, 0);
	glScalef(0.1,0.3,0.1);
	glutSolidCube(10);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(4.01, -5.7, -4.0);
	glScalef(0.6,1,0.5);
	glutSolidSphere(2.0, 20, 16);
	glPopMatrix();
	}
}

void CMfcglView::body(int ShadowCheck)//��
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glColor3f(1,0,1);
	glTranslatef(0, 2, 0);
	glRotatef(0, 0, 0, 1);
	glTranslatef(0,0.5,0);
	glScalef(1.2,0.8,1.0);
	glutSolidCube(5.0);
	glPopMatrix();
	}
	else if(ShadowCheck == 1){
	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(0, 2, 0);
	glRotatef(0, 0, 0, 1);
	glTranslatef(0,0.5,0);
	glScalef(1.2,0.8,1.0);
	glutSolidCube(5.0);
	glPopMatrix();
	
	}
}

void CMfcglView::head(int ShadowCheck)//�Ӹ�
{
	if(ShadowCheck == 0){
	glPushMatrix();
	glTranslatef(0, 6, -0.3);
	glRotatef(0, 0, 0, 1);
	glTranslatef(0,0.5,0);
	glScalef(1,0.7,0.5);
	glutSolidSphere(3.0, 20, 16);
	glPopMatrix();
	}
	else if(ShadowCheck == 1){
	glPushMatrix();
	glColor3f(0,0,0);
	glTranslatef(0, 6, -0.3);
	glRotatef(0, 0, 0, 1);
	glTranslatef(0,0.5,0);
	glScalef(1,0.7,0.5);
	glutSolidSphere(3.0, 20, 16);
	glPopMatrix();
	}
	

}

void CMfcglView::CheckGameState()
{
	if ( GameState == GAME_END_WIN )      // ���� ���������� GAME_END_WIN�� ���ٸ� 
	 {
	KillTimer(101);// ���� ���������� ���� ����      
	 // �޽��� �ڽ� ��� 
		stage=0;
	z_B =-100;
	z_B1 =-100;
	z_B2 =-100;
	z_B3 =-100;
	z_B4 =-100;
	temp=0;
	temp1=0;
	temp2=0;
	temp3=0;
	temp4=0;
	aa=0;
	speedadd =0;
	R_stage =1;
	 Invalidate();                 // ȭ���� �����ٰ� �ٽ� �׸��� �Լ� ȣ�� 
	 AfxMessageBox("You Win!!"); 
	 GameState= 1;
 
	}
	else if(GameState == GAME_START){
		AfxMessageBox("Start!!");  // �޽��� �ڽ� ��� 
		GameState= 1;
		Invalidate();                 // ȭ���� �����ٰ� �ٽ� �׸��� �Լ� ȣ�� 
		
	}

	else if (GameState == GAME_END_LOST )      // ���� ���������� GAME_END_LOST ���ٸ�  
	{
	KillTimer(101);// ���� ����  
	GameState = 0;
	GameState = GAME_EXIT;    	

	Invalidate();		// ȭ���� �����ٰ� �ٽ� �׸��� �Լ� ȣ��  
	
	stage=0;
	z_B =-100;
	z_B1 =-100;
	z_B2 =-100;
	z_B3 =-100;
	z_B4 =-100;
	temp=0;
	temp1=0;
	temp2=0;
	temp3=0;
	temp4=0;
	aa=0;
	speedadd =0;
	R_stage =1;
	AfxMessageBox("You lose !!\n Replay : ��Ŭ��");  // �޽��� �ڽ� ��� 	

	
 }
}

void CMfcglView::drawcone()//���� ���ý�
{	
	glPushMatrix();	
	glColor3f(1.0f,1.0f,0.0f);
	glTranslatef(0, 0, 10);
	glutSolidCone(2, 2.0, 8, 4);
	glPopMatrix();
}

void CMfcglView::face_eye()//��
{

	glPushMatrix();
	glColor3f(0.0f,0.0f,0.0f);
	glTranslatef(1, 8, 1.2);
	glScalef(1,0.7,0.5);
	glutSolidSphere(0.5, 20, 16);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0f,0.0f,0.0f);
	glTranslatef(-1, 8, 1.2);
	glScalef(1,0.7,0.5);
	glutSolidSphere(0.5, 20, 16);
	glPopMatrix();

}

void CMfcglView::face_mouth()//��
{
	glPushMatrix();
	glColor3f(0.0f,0.0f,0.0f);
	glTranslatef(0, 1.5, 1.8);
	glBegin(GL_LINES);
	glVertex3f(0, 5.75, 0);
	glVertex3f(-0.5, 5.25, 0);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(0, 5.75,0);
	glVertex3f(0.5, 5.25, 0);
	glEnd();
	glPopMatrix();

}

void CMfcglView::drawcone_nocolor()//�׸��ڸ� �׸��� ���� ���� ������ ����
{	
	glPushMatrix();	
	glTranslatef(0, 0, 10);
	glutSolidCone(2, 2.0, 8, 4);
	glPopMatrix();
}